export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      buche: {
        Row: {
          handicap_index: number | null
          id: string
          metri: number | null
          numero: number
          par: number
          percorso_id: string | null
        }
        Insert: {
          handicap_index?: number | null
          id?: string
          metri?: number | null
          numero: number
          par: number
          percorso_id?: string | null
        }
        Update: {
          handicap_index?: number | null
          id?: string
          metri?: number | null
          numero?: number
          par?: number
          percorso_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "buche_percorso_id_fkey"
            columns: ["percorso_id"]
            isOneToOne: false
            referencedRelation: "percorsi"
            referencedColumns: ["id"]
          },
        ]
      }
      circoli: {
        Row: {
          citta: string | null
          data_creazione: string | null
          id: string
          nome: string
          provincia: string | null
        }
        Insert: {
          citta?: string | null
          data_creazione?: string | null
          id?: string
          nome: string
          provincia?: string | null
        }
        Update: {
          citta?: string | null
          data_creazione?: string | null
          id?: string
          nome?: string
          provincia?: string | null
        }
        Relationships: []
      }
      circoli_italiani: {
        Row: {
          citta: string | null
          created_at: string | null
          id: string
          nome: string
          provincia: string | null
          regione: string | null
        }
        Insert: {
          citta?: string | null
          created_at?: string | null
          id?: string
          nome: string
          provincia?: string | null
          regione?: string | null
        }
        Update: {
          citta?: string | null
          created_at?: string | null
          id?: string
          nome?: string
          provincia?: string | null
          regione?: string | null
        }
        Relationships: []
      }
      configurazione_incassi: {
        Row: {
          anno: number
          data_reset: string | null
          id: string
          note: string | null
          saldo_iniziale: number | null
        }
        Insert: {
          anno: number
          data_reset?: string | null
          id?: string
          note?: string | null
          saldo_iniziale?: number | null
        }
        Update: {
          anno?: number
          data_reset?: string | null
          id?: string
          note?: string | null
          saldo_iniziale?: number | null
        }
        Relationships: []
      }
      gare: {
        Row: {
          costo_iscritto_donna: number | null
          costo_iscritto_uomo: number | null
          costo_non_iscritto_donna: number | null
          costo_non_iscritto_uomo: number | null
          created_at: string | null
          data: string
          descrizione: string | null
          formula: string | null
          id: string
          incasso_totale: number | null
          luogo: string | null
          nome: string
          note: string | null
          numero_buche: number | null
          ora: string | null
          orario_fine: string | null
          orario_inizio: string | null
          percorso_id: string | null
          quota_iscrizione: number | null
          stato: Database["public"]["Enums"]["stato_gara"] | null
          tipo: string | null
        }
        Insert: {
          costo_iscritto_donna?: number | null
          costo_iscritto_uomo?: number | null
          costo_non_iscritto_donna?: number | null
          costo_non_iscritto_uomo?: number | null
          created_at?: string | null
          data: string
          descrizione?: string | null
          formula?: string | null
          id?: string
          incasso_totale?: number | null
          luogo?: string | null
          nome: string
          note?: string | null
          numero_buche?: number | null
          ora?: string | null
          orario_fine?: string | null
          orario_inizio?: string | null
          percorso_id?: string | null
          quota_iscrizione?: number | null
          stato?: Database["public"]["Enums"]["stato_gara"] | null
          tipo?: string | null
        }
        Update: {
          costo_iscritto_donna?: number | null
          costo_iscritto_uomo?: number | null
          costo_non_iscritto_donna?: number | null
          costo_non_iscritto_uomo?: number | null
          created_at?: string | null
          data?: string
          descrizione?: string | null
          formula?: string | null
          id?: string
          incasso_totale?: number | null
          luogo?: string | null
          nome?: string
          note?: string | null
          numero_buche?: number | null
          ora?: string | null
          orario_fine?: string | null
          orario_inizio?: string | null
          percorso_id?: string | null
          quota_iscrizione?: number | null
          stato?: Database["public"]["Enums"]["stato_gara"] | null
          tipo?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "gare_percorso_id_fkey"
            columns: ["percorso_id"]
            isOneToOne: false
            referencedRelation: "percorsi"
            referencedColumns: ["id"]
          },
        ]
      }
      incassi: {
        Row: {
          anno: number | null
          created_at: string | null
          data: string
          descrizione: string | null
          gara_id: string | null
          id: string
          importo: number | null
          socio_id: string | null
          tipo: Database["public"]["Enums"]["tipo_incasso"] | null
        }
        Insert: {
          anno?: number | null
          created_at?: string | null
          data?: string
          descrizione?: string | null
          gara_id?: string | null
          id?: string
          importo?: number | null
          socio_id?: string | null
          tipo?: Database["public"]["Enums"]["tipo_incasso"] | null
        }
        Update: {
          anno?: number | null
          created_at?: string | null
          data?: string
          descrizione?: string | null
          gara_id?: string | null
          id?: string
          importo?: number | null
          socio_id?: string | null
          tipo?: Database["public"]["Enums"]["tipo_incasso"] | null
        }
        Relationships: [
          {
            foreignKeyName: "incassi_gara_id_fkey"
            columns: ["gara_id"]
            isOneToOne: false
            referencedRelation: "gare"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "incassi_socio_id_fkey"
            columns: ["socio_id"]
            isOneToOne: false
            referencedRelation: "soci"
            referencedColumns: ["id"]
          },
        ]
      }
      iscrizioni: {
        Row: {
          created_at: string | null
          data_iscrizione: string | null
          gara_id: string | null
          id: string
          importo_dovuto: number | null
          importo_pagato: number | null
          pagamento_effettuato: boolean | null
          pagato: boolean | null
          socio_id: string | null
        }
        Insert: {
          created_at?: string | null
          data_iscrizione?: string | null
          gara_id?: string | null
          id?: string
          importo_dovuto?: number | null
          importo_pagato?: number | null
          pagamento_effettuato?: boolean | null
          pagato?: boolean | null
          socio_id?: string | null
        }
        Update: {
          created_at?: string | null
          data_iscrizione?: string | null
          gara_id?: string | null
          id?: string
          importo_dovuto?: number | null
          importo_pagato?: number | null
          pagamento_effettuato?: boolean | null
          pagato?: boolean | null
          socio_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "iscrizioni_gara_id_fkey"
            columns: ["gara_id"]
            isOneToOne: false
            referencedRelation: "gare"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "iscrizioni_socio_id_fkey"
            columns: ["socio_id"]
            isOneToOne: false
            referencedRelation: "soci"
            referencedColumns: ["id"]
          },
        ]
      }
      notifiche: {
        Row: {
          data_creazione: string | null
          data_lettura: string | null
          id: string
          messaggio: string
          socio_id: string | null
          stato: string | null
          tipo: string
        }
        Insert: {
          data_creazione?: string | null
          data_lettura?: string | null
          id?: string
          messaggio: string
          socio_id?: string | null
          stato?: string | null
          tipo: string
        }
        Update: {
          data_creazione?: string | null
          data_lettura?: string | null
          id?: string
          messaggio?: string
          socio_id?: string | null
          stato?: string | null
          tipo?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifiche_socio_id_fkey"
            columns: ["socio_id"]
            isOneToOne: false
            referencedRelation: "soci"
            referencedColumns: ["id"]
          },
        ]
      }
      percorsi: {
        Row: {
          course_rating: number | null
          id: string
          nome: string
          numero_buche: number | null
          par: number | null
          slope_rating: number | null
        }
        Insert: {
          course_rating?: number | null
          id?: string
          nome: string
          numero_buche?: number | null
          par?: number | null
          slope_rating?: number | null
        }
        Update: {
          course_rating?: number | null
          id?: string
          nome?: string
          numero_buche?: number | null
          par?: number | null
          slope_rating?: number | null
        }
        Relationships: []
      }
      prenotazione_servizi: {
        Row: {
          id: string
          quantita: number | null
          servizio_id: string | null
          tee_time_id: string | null
        }
        Insert: {
          id?: string
          quantita?: number | null
          servizio_id?: string | null
          tee_time_id?: string | null
        }
        Update: {
          id?: string
          quantita?: number | null
          servizio_id?: string | null
          tee_time_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "prenotazione_servizi_servizio_id_fkey"
            columns: ["servizio_id"]
            isOneToOne: false
            referencedRelation: "servizi"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prenotazione_servizi_tee_time_id_fkey"
            columns: ["tee_time_id"]
            isOneToOne: false
            referencedRelation: "tee_times"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          cognome: string
          created_at: string | null
          id: string
          nome: string
          role: Database["public"]["Enums"]["app_role"] | null
        }
        Insert: {
          cognome: string
          created_at?: string | null
          id: string
          nome: string
          role?: Database["public"]["Enums"]["app_role"] | null
        }
        Update: {
          cognome?: string
          created_at?: string | null
          id?: string
          nome?: string
          role?: Database["public"]["Enums"]["app_role"] | null
        }
        Relationships: []
      }
      risultati: {
        Row: {
          created_at: string | null
          handicap_giocato: number | null
          id: string
          iscrizione_id: string | null
          note: string | null
          posizione: number | null
          punteggio_lordo: number | null
          punteggio_netto: number | null
          punti_stableford: number | null
          score_per_buca: Json | null
        }
        Insert: {
          created_at?: string | null
          handicap_giocato?: number | null
          id?: string
          iscrizione_id?: string | null
          note?: string | null
          posizione?: number | null
          punteggio_lordo?: number | null
          punteggio_netto?: number | null
          punti_stableford?: number | null
          score_per_buca?: Json | null
        }
        Update: {
          created_at?: string | null
          handicap_giocato?: number | null
          id?: string
          iscrizione_id?: string | null
          note?: string | null
          posizione?: number | null
          punteggio_lordo?: number | null
          punteggio_netto?: number | null
          punti_stableford?: number | null
          score_per_buca?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "risultati_iscrizione_id_fkey"
            columns: ["iscrizione_id"]
            isOneToOne: false
            referencedRelation: "iscrizioni"
            referencedColumns: ["id"]
          },
        ]
      }
      score_buche: {
        Row: {
          buca_numero: number
          colpi: number
          id: string
          punti_stableford: number | null
          risultato_id: string | null
        }
        Insert: {
          buca_numero: number
          colpi: number
          id?: string
          punti_stableford?: number | null
          risultato_id?: string | null
        }
        Update: {
          buca_numero?: number
          colpi?: number
          id?: string
          punti_stableford?: number | null
          risultato_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "score_buche_risultato_id_fkey"
            columns: ["risultato_id"]
            isOneToOne: false
            referencedRelation: "risultati"
            referencedColumns: ["id"]
          },
        ]
      }
      servizi: {
        Row: {
          descrizione: string | null
          disponibilita: number | null
          id: string
          nome: string
          prezzo: number | null
        }
        Insert: {
          descrizione?: string | null
          disponibilita?: number | null
          id?: string
          nome: string
          prezzo?: number | null
        }
        Update: {
          descrizione?: string | null
          disponibilita?: number | null
          id?: string
          nome?: string
          prezzo?: number | null
        }
        Relationships: []
      }
      soci: {
        Row: {
          circolo_appartenenza: string | null
          cognome: string
          created_at: string | null
          data_iscrizione: string | null
          data_nascita: string | null
          email: string | null
          handicap: number | null
          id: string
          indirizzo: string | null
          iscritto_circolo: boolean | null
          nome: string
          note: string | null
          senior: boolean | null
          sesso: Database["public"]["Enums"]["sesso_type"] | null
          stato: Database["public"]["Enums"]["stato_socio"] | null
          telefono: string | null
          tessera_federale: string | null
          user_id: string | null
        }
        Insert: {
          circolo_appartenenza?: string | null
          cognome: string
          created_at?: string | null
          data_iscrizione?: string | null
          data_nascita?: string | null
          email?: string | null
          handicap?: number | null
          id?: string
          indirizzo?: string | null
          iscritto_circolo?: boolean | null
          nome: string
          note?: string | null
          senior?: boolean | null
          sesso?: Database["public"]["Enums"]["sesso_type"] | null
          stato?: Database["public"]["Enums"]["stato_socio"] | null
          telefono?: string | null
          tessera_federale?: string | null
          user_id?: string | null
        }
        Update: {
          circolo_appartenenza?: string | null
          cognome?: string
          created_at?: string | null
          data_iscrizione?: string | null
          data_nascita?: string | null
          email?: string | null
          handicap?: number | null
          id?: string
          indirizzo?: string | null
          iscritto_circolo?: boolean | null
          nome?: string
          note?: string | null
          senior?: boolean | null
          sesso?: Database["public"]["Enums"]["sesso_type"] | null
          stato?: Database["public"]["Enums"]["stato_socio"] | null
          telefono?: string | null
          tessera_federale?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "soci_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      tee_times: {
        Row: {
          created_at: string | null
          data: string
          id: string
          note: string | null
          numero_giocatori: number | null
          ora: string
          percorso_id: string | null
          socio_id: string | null
          stato: Database["public"]["Enums"]["stato_prenotazione"] | null
        }
        Insert: {
          created_at?: string | null
          data: string
          id?: string
          note?: string | null
          numero_giocatori?: number | null
          ora: string
          percorso_id?: string | null
          socio_id?: string | null
          stato?: Database["public"]["Enums"]["stato_prenotazione"] | null
        }
        Update: {
          created_at?: string | null
          data?: string
          id?: string
          note?: string | null
          numero_giocatori?: number | null
          ora?: string
          percorso_id?: string | null
          socio_id?: string | null
          stato?: Database["public"]["Enums"]["stato_prenotazione"] | null
        }
        Relationships: [
          {
            foreignKeyName: "tee_times_percorso_id_fkey"
            columns: ["percorso_id"]
            isOneToOne: false
            referencedRelation: "percorsi"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tee_times_socio_id_fkey"
            columns: ["socio_id"]
            isOneToOne: false
            referencedRelation: "soci"
            referencedColumns: ["id"]
          },
        ]
      }
      variazioni_handicap: {
        Row: {
          created_at: string | null
          data: string
          gara_id: string | null
          id: string
          nuovo_handicap: number | null
          punti_stableford: number | null
          socio_id: string | null
          variazione: number | null
          vecchio_handicap: number | null
        }
        Insert: {
          created_at?: string | null
          data?: string
          gara_id?: string | null
          id?: string
          nuovo_handicap?: number | null
          punti_stableford?: number | null
          socio_id?: string | null
          variazione?: number | null
          vecchio_handicap?: number | null
        }
        Update: {
          created_at?: string | null
          data?: string
          gara_id?: string | null
          id?: string
          nuovo_handicap?: number | null
          punti_stableford?: number | null
          socio_id?: string | null
          variazione?: number | null
          vecchio_handicap?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "variazioni_handicap_gara_id_fkey"
            columns: ["gara_id"]
            isOneToOne: false
            referencedRelation: "gare"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "variazioni_handicap_socio_id_fkey"
            columns: ["socio_id"]
            isOneToOne: false
            referencedRelation: "soci"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_user_role: {
        Args: { user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      update_senior_status: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "staff" | "socio"
      sesso_type: "M" | "F"
      stato_gara: "Programmata" | "In corso" | "Completata" | "Annullata"
      stato_prenotazione: "Confermato" | "Cancellato" | "In attesa"
      stato_socio: "Attivo" | "Sospeso" | "Inattivo"
      tipo_incasso: "Gara" | "Iscrizione" | "Servizio" | "Altro"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "staff", "socio"],
      sesso_type: ["M", "F"],
      stato_gara: ["Programmata", "In corso", "Completata", "Annullata"],
      stato_prenotazione: ["Confermato", "Cancellato", "In attesa"],
      stato_socio: ["Attivo", "Sospeso", "Inattivo"],
      tipo_incasso: ["Gara", "Iscrizione", "Servizio", "Altro"],
    },
  },
} as const
