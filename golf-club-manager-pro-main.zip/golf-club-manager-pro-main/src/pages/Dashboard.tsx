import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Navbar } from '@/components/layout/Navbar';
import { Sidebar } from '@/components/layout/Sidebar';
import { DashboardStats } from '@/components/dashboard/DashboardStats';
import { StatisticheSection } from '@/components/dashboard/StatisticheSection';
import { SociList } from '@/components/soci/SociList';
import { GareList } from '@/components/gare/GareList';
import { CircoliList } from '@/components/circoli/CircoliList';
import { PercorsiList } from '@/components/percorsi/PercorsiList';
import { RisultatiList } from '@/components/risultati/RisultatiList';
import { ClassificaFinaleSection } from '@/components/risultati/ClassificaFinaleSection';
import { LoginForm } from '@/components/auth/LoginForm';
import { RegisterForm } from '@/components/auth/RegisterForm';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export const Dashboard = () => {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [showRegister, setShowRegister] = useState(false);

  const { data: profile } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
      return data;
    },
    enabled: !!user?.id,
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Caricamento...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center">
        <div className="max-w-md w-full mx-4">
          {showRegister ? (
            <div className="space-y-4">
              <RegisterForm />
              <div className="text-center">
                <Button 
                  variant="link" 
                  onClick={() => setShowRegister(false)}
                >
                  Hai già un account? Accedi
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <LoginForm />
              <div className="text-center">
                <Button 
                  variant="link" 
                  onClick={() => setShowRegister(true)}
                >
                  Non hai un account? Registrati
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <DashboardStats />;
      case 'soci':
        return <SociList />;
      case 'circoli':
        return <CircoliList />;
      case 'percorsi':
        return <PercorsiList />;
      case 'gare':
        return <GareList />;
      case 'risultati':
        return <RisultatiList />;
      case 'classifica-finale':
        return <ClassificaFinaleSection />;
      case 'statistiche':
        return <StatisticheSection />;
      default:
        return <DashboardStats />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="flex">
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
        
        <main className="flex-1 p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};
