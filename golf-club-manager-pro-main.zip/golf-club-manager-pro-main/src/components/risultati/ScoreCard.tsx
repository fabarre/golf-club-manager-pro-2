
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { calculateResults } from './utils/scoreCalculations';

interface ScoreCardProps {
  iscrizioneId: string;
  buche: Array<{ numero: number; par: number; handicap_index: number }>;
  scores: { [buca: number]: number };
  handicapGiocato: number;
  formula: string;
  onScoreChange: (iscrizioneId: string, buca: number, colpi: number) => void;
}

export const ScoreCard = ({ 
  iscrizioneId, 
  buche, 
  scores, 
  handicapGiocato, 
  formula, 
  onScoreChange 
}: ScoreCardProps) => {
  
  // Calcola i risultati in tempo reale
  const risultati = calculateResults(scores, handicapGiocato, buche, formula);

  const getStatusLabel = (punti: number): string => {
    if (punti === 0) return 'Blob';
    if (punti === 1) return 'Doppio Bogey';
    if (punti === 2) return 'Par';
    if (punti === 3) return 'Birdie';
    if (punti === 4) return 'Eagle';
    if (punti >= 5) return 'Albatross';
    return 'Bogey';
  };

  const isStableford = formula === 'Stableford';

  return (
    <div className="space-y-4">
      {/* Griglia delle buche */}
      <div className={`grid gap-2 text-sm ${isStableford ? 'grid-cols-8' : 'grid-cols-5'}`}>
        {/* Intestazioni */}
        <div className="font-semibold text-center py-2 border-b">Buca</div>
        <div className="font-semibold text-center py-2 border-b">Par</div>
        <div className="font-semibold text-center py-2 border-b">HCP</div>
        <div className="font-semibold text-center py-2 border-b">Colpi</div>
        {isStableford ? (
          <>
            <div className="font-semibold text-center py-2 border-b">Lordo Stableford</div>
            <div className="font-semibold text-center py-2 border-b">Netto Stableford</div>
            <div className="font-semibold text-center py-2 border-b col-span-2">Status</div>
          </>
        ) : (
          <div className="font-semibold text-center py-2 border-b">Netto Medal</div>
        )}

        {/* Buche */}
        {buche.map((buca) => {
          const colpi = scores[buca.numero] || 0;
          const scoreInfo = risultati.scorePerBuca[buca.numero];
          
          return (
            <div key={buca.numero} className="contents">
              <div className="text-center py-2 bg-gray-50">{buca.numero}</div>
              <div className="text-center py-2 bg-gray-50">{buca.par}</div>
              <div className="text-center py-2 bg-gray-50">{buca.handicap_index}</div>
              <div className="py-1">
                <Input
                  type="number"
                  min="1"
                  max="15"
                  value={colpi || ''}
                  onChange={(e) => onScoreChange(iscrizioneId, buca.numero, parseInt(e.target.value) || 0)}
                  className="w-16 h-8 text-center"
                  placeholder="-"
                />
              </div>
              
              {isStableford ? (
                <>
                  {/* Per Stableford: Lordo = punti calcolati sul punteggio lordo */}
                  <div className="text-center py-2 bg-blue-50">
                    {scoreInfo ? Math.max(0, 2 - (colpi - buca.par)) : '-'}
                  </div>
                  {/* Per Stableford: Netto = punti Stableford finali */}
                  <div className="text-center py-2 font-semibold bg-blue-100">
                    {scoreInfo?.punti || '-'}
                  </div>
                  <div className="col-span-2 py-1">
                    {scoreInfo && colpi > 0 && (
                      <Badge 
                        variant={
                          scoreInfo.punti >= 3 ? 'default' : 
                          scoreInfo.punti >= 2 ? 'secondary' : 
                          'outline'
                        }
                        className="text-xs"
                      >
                        {getStatusLabel(scoreInfo.punti)}
                      </Badge>
                    )}
                  </div>
                </>
              ) : (
                /* Per Medal: Netto = colpi meno handicap buca */
                <div className="text-center py-2 font-semibold bg-green-100">
                  {scoreInfo?.netto || '-'}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Totali */}
      <div className="border-t pt-4">
        <div className={`grid gap-6 text-sm ${isStableford ? 'grid-cols-4' : 'grid-cols-3'}`}>
          {isStableford ? (
            <>
              <div className="text-center">
                <div className="font-semibold text-gray-600">Totale Colpi</div>
                <div className="text-2xl font-bold mt-1">{risultati.punteggioLordo || '-'}</div>
              </div>
              <div className="text-center">
                <div className="font-semibold text-gray-600">Punti Lordi Stableford</div>
                <div className="text-2xl font-bold mt-1 text-blue-600">
                  {Object.values(risultati.scorePerBuca).reduce((total, score) => {
                    const bucaNumero = parseInt(Object.keys(risultati.scorePerBuca).find(k => risultati.scorePerBuca[parseInt(k)] === score) || '0');
                    const colpi = scores[bucaNumero] || 0;
                    const bucaInfo = buche.find(b => b.numero === bucaNumero);
                    return total + (bucaInfo ? Math.max(0, 2 - (colpi - bucaInfo.par)) : 0);
                  }, 0) || '-'}
                </div>
              </div>
              <div className="text-center">
                <div className="font-semibold text-gray-600">Punti Netti Stableford</div>
                <div className="text-2xl font-bold mt-1 text-green-600">{risultati.puntiStableford || '-'}</div>
              </div>
            </>
          ) : (
            <>
              <div className="text-center">
                <div className="font-semibold text-gray-600">Lordo Medal</div>
                <div className="text-2xl font-bold mt-1">{risultati.punteggioLordo || '-'}</div>
              </div>
              <div className="text-center">
                <div className="font-semibold text-gray-600">Netto Medal</div>
                <div className="text-2xl font-bold mt-1 text-green-600">{risultati.punteggioNetto || '-'}</div>
              </div>
            </>
          )}
          <div className="text-center">
            <div className="font-semibold text-gray-600">HCP Giocato</div>
            <div className="text-2xl font-bold mt-1 text-gray-800">{handicapGiocato}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
