
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Award } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface ClassificheSectionProps {
  garaId: string;
  formula: string;
}

interface RisultatoClassifica {
  id: string;
  nome: string;
  cognome: string;
  sesso: string;
  senior: boolean;
  punteggio_lordo: number;
  punteggio_netto: number;
  punti_stableford: number;
  handicap_giocato: number;
}

export const ClassificheSection = ({ garaId, formula }: ClassificheSectionProps) => {
  const { data: risultati, isLoading } = useQuery({
    queryKey: ['classifiche', garaId],
    queryFn: async () => {
      console.log('Caricamento classifiche per gara:', garaId);
      
      const { data, error } = await supabase
        .from('risultati')
        .select(`
          id,
          punteggio_lordo,
          punteggio_netto,
          punti_stableford,
          handicap_giocato,
          iscrizioni!inner (
            id,
            gara_id,
            soci (
              nome,
              cognome,
              sesso,
              senior
            )
          )
        `)
        .eq('iscrizioni.gara_id', garaId)
        .not('punteggio_lordo', 'is', null);

      console.log('Risultati query classifiche:', data);
      console.log('Errore query classifiche:', error);

      if (error) throw error;

      return data?.map((r: any) => ({
        id: r.id,
        nome: r.iscrizioni.soci.nome,
        cognome: r.iscrizioni.soci.cognome,
        sesso: r.iscrizioni.soci.sesso,
        senior: r.iscrizioni.soci.senior,
        punteggio_lordo: r.punteggio_lordo,
        punteggio_netto: r.punteggio_netto,
        punti_stableford: r.punti_stableford,
        handicap_giocato: r.handicap_giocato
      })) || [];
    },
    enabled: !!garaId,
  });

  // Query per ottenere i dati delle buche necessari per calcolare i punti Stableford lordi
  const { data: garaData } = useQuery({
    queryKey: ['gara-buche', garaId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('gare')
        .select(`
          percorsi (
            buche (numero, par)
          )
        `)
        .eq('id', garaId)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!garaId,
  });

  // Query per ottenere gli score per buca per calcolare i punti Stableford lordi (solo per Stableford)
  const { data: scoresBuche } = useQuery({
    queryKey: ['scores-buche', garaId],
    queryFn: async () => {
      if (!risultati) return {};

      const risultatiIds = risultati.map(r => r.id);
      const { data, error } = await supabase
        .from('score_buche')
        .select('risultato_id, buca_numero, colpi')
        .in('risultato_id', risultatiIds);

      if (error) throw error;

      // Raggruppa per risultato_id
      const scoresByRisultato: { [key: string]: { [buca: number]: number } } = {};
      data?.forEach(score => {
        if (!scoresByRisultato[score.risultato_id]) {
          scoresByRisultato[score.risultato_id] = {};
        }
        scoresByRisultato[score.risultato_id][score.buca_numero] = score.colpi;
      });

      return scoresByRisultato;
    },
    enabled: !!risultati && risultati.length > 0 && formula === 'Stableford',
  });

  // Funzione per calcolare i punti Stableford lordi (solo per Stableford)
  const calcolaPuntiStablefordLordi = (risultatoId: string) => {
    if (formula !== 'Stableford' || !scoresBuche || !garaData?.percorsi?.buche) {
      return 0;
    }

    const scoresRisultato = scoresBuche[risultatoId];
    if (!scoresRisultato) return 0;

    let puntiTotali = 0;
    Object.entries(scoresRisultato).forEach(([bucaNumero, colpi]) => {
      const buca = garaData.percorsi.buche.find((b: any) => b.numero === parseInt(bucaNumero));
      if (buca && colpi > 0) {
        // Calcolo Stableford lordo: 2 punti per il par, +1 per ogni colpo sotto, -1 per ogni colpo sopra
        const differenzaDalPar = colpi - buca.par;
        const punti = Math.max(0, 2 - differenzaDalPar);
        puntiTotali += punti;
      }
    });

    return puntiTotali;
  };

  const calcolaClassifica = (risultati: RisultatoClassifica[], tipo: 'lordo' | 'netto', sesso?: 'M' | 'F') => {
    let filtered = risultati;
    
    if (sesso) {
      filtered = risultati.filter(r => r.sesso === sesso);
    }

    return filtered.sort((a, b) => {
      if (formula === 'Stableford') {
        if (tipo === 'lordo') {
          // Per classifica lordo Stableford: ordina per punti Stableford lordi (più punti = meglio)
          const puntiLordiA = calcolaPuntiStablefordLordi(a.id);
          const puntiLordiB = calcolaPuntiStablefordLordi(b.id);
          return puntiLordiB - puntiLordiA;
        } else {
          // Per classifica netto Stableford: ordina per punti Stableford (più punti = meglio)
          return (b.punti_stableford || 0) - (a.punti_stableford || 0);
        }
      } else {
        // Medal: meno colpi = meglio, distinguere tra lordo e netto
        const scoreA = tipo === 'lordo' ? a.punteggio_lordo : a.punteggio_netto;
        const scoreB = tipo === 'lordo' ? b.punteggio_lordo : b.punteggio_netto;
        return (scoreA || 999) - (scoreB || 999);
      }
    }).map((risultato, index) => ({
      ...risultato,
      posizione: index + 1
    }));
  };

  const renderClassifica = (classifica: (RisultatoClassifica & { posizione: number })[], tipo: 'lordo' | 'netto') => {
    if (classifica.length === 0) {
      return (
        <div className="text-center py-8 text-gray-500">
          Nessun risultato disponibile
        </div>
      );
    }

    // Determina il titolo della colonna
    const getColumnTitle = () => {
      if (formula === 'Stableford') {
        return tipo === 'lordo' ? 'Punti Lordi' : 'Punti Netti';
      } else {
        return tipo === 'lordo' ? 'Lordo' : 'Netto';
      }
    };

    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-16">Pos.</TableHead>
            <TableHead>Nome</TableHead>
            <TableHead className="text-center">HCP</TableHead>
            <TableHead className="text-center">
              {getColumnTitle()}
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {classifica.map((risultato) => {
            let scoreToShow;
            
            if (formula === 'Stableford') {
              if (tipo === 'lordo') {
                // Per Stableford lordo: mostra i punti Stableford lordi calcolati
                scoreToShow = calcolaPuntiStablefordLordi(risultato.id);
              } else {
                // Per Stableford netto: mostra i punti Stableford netti
                scoreToShow = risultato.punti_stableford;
              }
            } else {
              // Per Medal: mostra il punteggio lordo o netto
              scoreToShow = tipo === 'lordo' ? risultato.punteggio_lordo : risultato.punteggio_netto;
            }
            
            return (
              <TableRow key={risultato.id}>
                <TableCell className="font-medium">
                  <div className="flex items-center space-x-2">
                    {risultato.posizione === 1 && <Trophy className="h-4 w-4 text-yellow-500" />}
                    {risultato.posizione === 2 && <Medal className="h-4 w-4 text-gray-400" />}
                    {risultato.posizione === 3 && <Award className="h-4 w-4 text-amber-600" />}
                    <span>{risultato.posizione}°</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <span>{risultato.nome} {risultato.cognome}</span>
                    <div className="flex space-x-1">
                      <Badge variant="outline" className="text-xs">
                        {risultato.sesso === 'M' ? 'Uomo' : 'Donna'}
                      </Badge>
                      {risultato.senior && (
                        <Badge variant="secondary" className="text-xs">
                          Senior
                        </Badge>
                      )}
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-center">{risultato.handicap_giocato}</TableCell>
                <TableCell className="text-center font-semibold">
                  {scoreToShow}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
            <p className="mt-2 text-gray-600">Caricamento classifiche...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!risultati || risultati.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5" />
            <span>Classifiche</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8 text-gray-500">
          Nessun risultato disponibile per le classifiche
        </CardContent>
      </Card>
    );
  }

  const classificaGeneraleLordo = calcolaClassifica(risultati, 'lordo');
  const classificaGeneraleNetto = calcolaClassifica(risultati, 'netto');
  const classificaUomoLordo = calcolaClassifica(risultati, 'lordo', 'M');
  const classificaUomoNetto = calcolaClassifica(risultati, 'netto', 'M');
  const classificaDonnaLordo = calcolaClassifica(risultati, 'lordo', 'F');
  const classificaDonnaNetto = calcolaClassifica(risultati, 'netto', 'F');

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Trophy className="h-5 w-5" />
          <span>Classifiche</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="generale-lordo" className="w-full">
          <TabsList className="grid grid-cols-6 w-full">
            <TabsTrigger value="generale-lordo">Generale Lordo</TabsTrigger>
            <TabsTrigger value="generale-netto">Generale Netto</TabsTrigger>
            <TabsTrigger value="uomo-lordo">Uomo Lordo</TabsTrigger>
            <TabsTrigger value="uomo-netto">Uomo Netto</TabsTrigger>
            <TabsTrigger value="donna-lordo">Donna Lordo</TabsTrigger>
            <TabsTrigger value="donna-netto">Donna Netto</TabsTrigger>
          </TabsList>
          
          <TabsContent value="generale-lordo" className="mt-4">
            {renderClassifica(classificaGeneraleLordo, 'lordo')}
          </TabsContent>
          
          <TabsContent value="generale-netto" className="mt-4">
            {renderClassifica(classificaGeneraleNetto, 'netto')}
          </TabsContent>
          
          <TabsContent value="uomo-lordo" className="mt-4">
            {renderClassifica(classificaUomoLordo, 'lordo')}
          </TabsContent>
          
          <TabsContent value="uomo-netto" className="mt-4">
            {renderClassifica(classificaUomoNetto, 'netto')}
          </TabsContent>
          
          <TabsContent value="donna-lordo" className="mt-4">
            {renderClassifica(classificaDonnaLordo, 'lordo')}
          </TabsContent>
          
          <TabsContent value="donna-netto" className="mt-4">
            {renderClassifica(classificaDonnaNetto, 'netto')}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};
