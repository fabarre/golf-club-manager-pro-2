
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Award, Target } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface RisultatoSocio {
  socio_id: string;
  nome: string;
  cognome: string;
  sesso: string;
  senior: boolean;
  risultati: {
    gara_id: string;
    gara_nome: string;
    data_gara: string;
    formula: string;
    punteggio_lordo: number;
    punteggio_netto: number;
    punti_stableford: number;
    punti_lordi_stableford: number;
  }[];
}

interface ClassificaSocio {
  socio_id: string;
  nome: string;
  cognome: string;
  sesso: string;
  senior: boolean;
  totale_punti_lordi: number;
  totale_punti_netti: number;
  gare_giocate: number;
  posizione: number;
}

export const ClassificaFinaleSection = () => {
  const { data: risultatiSoci, isLoading } = useQuery({
    queryKey: ['classifica-finale'],
    queryFn: async () => {
      console.log('Caricamento classifica finale...');
      
      // Query per ottenere tutti i risultati dei soci
      const { data, error } = await supabase
        .from('risultati')
        .select(`
          punteggio_lordo,
          punteggio_netto,
          punti_stableford,
          iscrizioni!inner (
            gara_id,
            gare!inner (
              id,
              nome,
              data,
              formula,
              stato
            ),
            soci!inner (
              id,
              nome,
              cognome,
              sesso,
              senior
            )
          )
        `)
        .eq('iscrizioni.gare.stato', 'Completata')
        .not('punteggio_lordo', 'is', null);

      console.log('Risultati query classifica finale:', data);
      console.log('Errore query:', error);

      if (error) throw error;

      return data;
    },
  });

  // Query per ottenere i dati delle buche e calcolare i punti Stableford lordi
  const { data: scoresBuche } = useQuery({
    queryKey: ['scores-buche-finale'],
    queryFn: async () => {
      if (!risultatiSoci) return {};

      const risultatiIds = risultatiSoci.map((r: any) => r.id);
      if (risultatiIds.length === 0) return {};

      const { data, error } = await supabase
        .from('score_buche')
        .select('risultato_id, buca_numero, colpi')
        .in('risultato_id', risultatiIds);

      if (error) throw error;

      // Raggruppa per risultato_id
      const scoresByRisultato: { [key: string]: { [buca: number]: number } } = {};
      data?.forEach(score => {
        if (!scoresByRisultato[score.risultato_id]) {
          scoresByRisultato[score.risultato_id] = {};
        }
        scoresByRisultato[score.risultato_id][score.buca_numero] = score.colpi;
      });

      return scoresByRisultato;
    },
    enabled: !!risultatiSoci && risultatiSoci.length > 0,
  });

  // Query per ottenere i dati delle buche per calcolare i punti Stableford lordi
  const { data: gareBuche } = useQuery({
    queryKey: ['gare-buche-finale'],
    queryFn: async () => {
      if (!risultatiSoci) return {};

      const gareIds = [...new Set(risultatiSoci.map((r: any) => r.iscrizioni.gara_id))];
      if (gareIds.length === 0) return {};

      const { data, error } = await supabase
        .from('gare')
        .select(`
          id,
          percorsi (
            buche (numero, par)
          )
        `)
        .in('id', gareIds);

      if (error) throw error;

      const gareBucheMap: { [garaId: string]: any[] } = {};
      data?.forEach(gara => {
        if (gara.percorsi?.buche) {
          gareBucheMap[gara.id] = gara.percorsi.buche;
        }
      });

      return gareBucheMap;
    },
    enabled: !!risultatiSoci && risultatiSoci.length > 0,
  });

  // Funzione per calcolare i punti Stableford lordi
  const calcolaPuntiStablefordLordi = (risultatoId: string, garaId: string) => {
    if (!scoresBuche || !gareBuche) return 0;

    const scoresRisultato = scoresBuche[risultatoId];
    const buche = gareBuche[garaId];
    
    if (!scoresRisultato || !buche) return 0;

    let puntiTotali = 0;
    Object.entries(scoresRisultato).forEach(([bucaNumero, colpi]) => {
      const buca = buche.find((b: any) => b.numero === parseInt(bucaNumero));
      if (buca && colpi > 0) {
        const differenzaDalPar = colpi - buca.par;
        const punti = Math.max(0, 2 - differenzaDalPar);
        puntiTotali += punti;
      }
    });

    return puntiTotali;
  };

  // Elabora i dati per creare la classifica finale
  const elaboraClassificaFinale = (): RisultatoSocio[] => {
    if (!risultatiSoci) return [];

    const sociMap = new Map<string, RisultatoSocio>();

    risultatiSoci.forEach((risultato: any) => {
      const socio = risultato.iscrizioni.soci;
      const gara = risultato.iscrizioni.gare;
      
      if (!sociMap.has(socio.id)) {
        sociMap.set(socio.id, {
          socio_id: socio.id,
          nome: socio.nome,
          cognome: socio.cognome,
          sesso: socio.sesso,
          senior: socio.senior,
          risultati: []
        });
      }

      const risultatoSocio = sociMap.get(socio.id)!;
      const puntiLordiStableford = gara.formula === 'Stableford' 
        ? calcolaPuntiStablefordLordi(risultato.id, gara.id)
        : 0;

      risultatoSocio.risultati.push({
        gara_id: gara.id,
        gara_nome: gara.nome,
        data_gara: gara.data,
        formula: gara.formula,
        punteggio_lordo: risultato.punteggio_lordo,
        punteggio_netto: risultato.punteggio_netto,
        punti_stableford: risultato.punti_stableford,
        punti_lordi_stableford: puntiLordiStableford
      });
    });

    return Array.from(sociMap.values());
  };

  const calcolaClassificaFinale = (
    risultatiSoci: RisultatoSocio[], 
    tipo: 'lordo' | 'netto', 
    sesso?: 'M' | 'F'
  ): ClassificaSocio[] => {
    let filtered = risultatiSoci;
    
    if (sesso) {
      filtered = risultatiSoci.filter(s => s.sesso === sesso);
    }

    const classifiche: ClassificaSocio[] = filtered.map(socio => {
      // Ordina i risultati per punti (dal più alto al più basso) e prendi i migliori 9
      const risultatiOrdinati = socio.risultati
        .map(risultato => {
          if (tipo === 'lordo') {
            return risultato.formula === 'Stableford' 
              ? risultato.punti_lordi_stableford 
              : (risultato.punteggio_lordo ? 72 - risultato.punteggio_lordo : 0);
          } else {
            return risultato.formula === 'Stableford' 
              ? risultato.punti_stableford 
              : (risultato.punteggio_netto ? 36 - risultato.punteggio_netto : 0);
          }
        })
        .sort((a, b) => b - a) // Ordina dal più alto al più basso
        .slice(0, 9); // Prendi i migliori 9

      const totalePunti = risultatiOrdinati.reduce((sum, punti) => sum + punti, 0);

      return {
        socio_id: socio.socio_id,
        nome: socio.nome,
        cognome: socio.cognome,
        sesso: socio.sesso,
        senior: socio.senior,
        totale_punti_lordi: tipo === 'lordo' ? totalePunti : 0,
        totale_punti_netti: tipo === 'netto' ? totalePunti : 0,
        gare_giocate: socio.risultati.length,
        posizione: 0
      };
    });

    // Ordina per totale punti (dal più alto al più basso) e assegna le posizioni
    return classifiche
      .sort((a, b) => {
        const punteggioA = tipo === 'lordo' ? a.totale_punti_lordi : a.totale_punti_netti;
        const punteggioB = tipo === 'lordo' ? b.totale_punti_lordi : b.totale_punti_netti;
        return punteggioB - punteggioA;
      })
      .map((socio, index) => ({
        ...socio,
        posizione: index + 1
      }));
  };

  const renderClassificaFinale = (classifica: ClassificaSocio[], tipo: 'lordo' | 'netto') => {
    if (classifica.length === 0) {
      return (
        <div className="text-center py-8 text-gray-500">
          Nessun risultato disponibile
        </div>
      );
    }

    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-16">Pos.</TableHead>
            <TableHead>Nome</TableHead>
            <TableHead className="text-center">Gare</TableHead>
            <TableHead className="text-center">
              Totale Punti {tipo === 'lordo' ? 'Lordi' : 'Netti'}
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {classifica.map((socio) => {
            const totalePunti = tipo === 'lordo' ? socio.totale_punti_lordi : socio.totale_punti_netti;
            
            return (
              <TableRow key={socio.socio_id}>
                <TableCell className="font-medium">
                  <div className="flex items-center space-x-2">
                    {socio.posizione === 1 && <Trophy className="h-4 w-4 text-yellow-500" />}
                    {socio.posizione === 2 && <Medal className="h-4 w-4 text-gray-400" />}
                    {socio.posizione === 3 && <Award className="h-4 w-4 text-amber-600" />}
                    <span>{socio.posizione}°</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <span>{socio.nome} {socio.cognome}</span>
                    <div className="flex space-x-1">
                      <Badge variant="outline" className="text-xs">
                        {socio.sesso === 'M' ? 'Uomo' : 'Donna'}
                      </Badge>
                      {socio.senior && (
                        <Badge variant="secondary" className="text-xs">
                          Senior
                        </Badge>
                      )}
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-center">{socio.gare_giocate}</TableCell>
                <TableCell className="text-center font-semibold">
                  {totalePunti.toFixed(1)}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
            <p className="mt-2 text-gray-600">Caricamento classifica finale...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const risultatiElaborati = elaboraClassificaFinale();

  if (risultatiElaborati.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Classifica Finale Generale</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8 text-gray-500">
          Nessun risultato disponibile per la classifica finale
        </CardContent>
      </Card>
    );
  }

  const classificaGeneraleLordo = calcolaClassificaFinale(risultatiElaborati, 'lordo');
  const classificaGeneraleNetto = calcolaClassificaFinale(risultatiElaborati, 'netto');
  const classificaUomoLordo = calcolaClassificaFinale(risultatiElaborati, 'lordo', 'M');
  const classificaUomoNetto = calcolaClassificaFinale(risultatiElaborati, 'netto', 'M');
  const classificaDonnaLordo = calcolaClassificaFinale(risultatiElaborati, 'lordo', 'F');
  const classificaDonnaNetto = calcolaClassificaFinale(risultatiElaborati, 'netto', 'F');

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Target className="h-5 w-5" />
          <span>Classifica Finale Generale</span>
        </CardTitle>
        <p className="text-sm text-gray-600 mt-1">
          Somma dei punti delle migliori 9 gare per ogni socio
        </p>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="generale-lordo" className="w-full">
          <TabsList className="grid grid-cols-6 w-full">
            <TabsTrigger value="generale-lordo">Generale Lordo</TabsTrigger>
            <TabsTrigger value="generale-netto">Generale Netto</TabsTrigger>
            <TabsTrigger value="uomo-lordo">Uomo Lordo</TabsTrigger>
            <TabsTrigger value="uomo-netto">Uomo Netto</TabsTrigger>
            <TabsTrigger value="donna-lordo">Donna Lordo</TabsTrigger>
            <TabsTrigger value="donna-netto">Donna Netto</TabsTrigger>
          </TabsList>
          
          <TabsContent value="generale-lordo" className="mt-4">
            {renderClassificaFinale(classificaGeneraleLordo, 'lordo')}
          </TabsContent>
          
          <TabsContent value="generale-netto" className="mt-4">
            {renderClassificaFinale(classificaGeneraleNetto, 'netto')}
          </TabsContent>
          
          <TabsContent value="uomo-lordo" className="mt-4">
            {renderClassificaFinale(classificaUomoLordo, 'lordo')}
          </TabsContent>
          
          <TabsContent value="uomo-netto" className="mt-4">
            {renderClassificaFinale(classificaUomoNetto, 'netto')}
          </TabsContent>
          
          <TabsContent value="donna-lordo" className="mt-4">
            {renderClassificaFinale(classificaDonnaLordo, 'lordo')}
          </TabsContent>
          
          <TabsContent value="donna-netto" className="mt-4">
            {renderClassificaFinale(classificaDonnaNetto, 'netto')}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};
