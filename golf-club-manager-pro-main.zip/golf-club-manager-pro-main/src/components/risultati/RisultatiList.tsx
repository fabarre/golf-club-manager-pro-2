
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Trophy, Calculator } from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { RisultatiForm } from './RisultatiForm';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import type { Database } from '@/integrations/supabase/types';

type StatoGara = Database['public']['Enums']['stato_gara'];

export const RisultatiList = () => {
  const [showForm, setShowForm] = useState(false);
  const [selectedGara, setSelectedGara] = useState<string | null>(null);

  const { data: gare, refetch } = useQuery({
    queryKey: ['gare-con-risultati'],
    queryFn: async () => {
      console.log('Caricamento TUTTE le gare per debug...');
      
      // Prima controlliamo tutte le gare per vedere gli stati
      const { data: tutteGare, error: errorTutte } = await supabase
        .from('gare')
        .select('id, nome, stato, data')
        .order('data', { ascending: false });
      
      console.log('TUTTE le gare nel database:', tutteGare);
      console.log('Stati trovati:', tutteGare?.map(g => ({ nome: g.nome, stato: g.stato })));
      
      // Ora proviamo con stato = 'Completata'
      const { data: gareCompletate, error: errorCompletate } = await supabase
        .from('gare')
        .select(`
          *,
          percorsi (nome, par),
          iscrizioni (
            id,
            soci (nome, cognome, handicap, sesso)
          )
        `)
        .eq('stato', 'Completata')
        .order('data', { ascending: false });
      
      console.log('Gare con stato Completata:', gareCompletate);
      console.log('Errore query completate:', errorCompletate);
      
      // Proviamo anche con tutti gli stati possibili
      const possibiliStati: StatoGara[] = ['Programmata', 'In corso', 'Completata', 'Annullata'];
      for (const stato of possibiliStati) {
        const { data: test } = await supabase
          .from('gare')
          .select('id, nome, stato')
          .eq('stato', stato);
        console.log(`Gare con stato "${stato}":`, test?.length || 0);
      }
      
      return gareCompletate || [];
    },
  });

  const handleGestisciRisultati = (garaId: string) => {
    setSelectedGara(garaId);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setSelectedGara(null);
  };

  const handleFormSuccess = () => {
    refetch();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestione Risultati</h2>
      </div>

      {showForm && selectedGara && (
        <Dialog open={showForm} onOpenChange={handleCloseForm}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Gestione Risultati Gara</DialogTitle>
            </DialogHeader>
            <RisultatiForm 
              garaId={selectedGara}
              onClose={handleCloseForm}
              onSuccess={handleFormSuccess}
            />
          </DialogContent>
        </Dialog>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {gare?.map((gara) => {
          const totalIscritti = gara.iscrizioni?.length || 0;
          
          return (
            <Card key={gara.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{gara.nome}</CardTitle>
                  <Trophy className="h-5 w-5 text-yellow-600" />
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm text-gray-600">
                  <span>Data: {format(new Date(gara.data), 'dd MMMM yyyy', { locale: it })}</span>
                </div>
                
                <div className="text-sm text-gray-600">
                  <span>Stato: <strong>{gara.stato}</strong></span>
                </div>
                
                {gara.percorsi && (
                  <div className="text-sm text-gray-600">
                    <span>Percorso: {gara.percorsi.nome}</span>
                  </div>
                )}

                <div className="text-sm">
                  <span className="text-gray-600">Formula:</span>
                  <div className="font-medium">{gara.formula}</div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-600">Iscritti:</span>
                    <div className="font-medium">{totalIscritti}</div>
                  </div>
                </div>

                <Button 
                  className="w-full"
                  onClick={() => handleGestisciRisultati(gara.id)}
                >
                  <Calculator className="h-4 w-4 mr-2" />
                  Gestisci Risultati
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {(!gare || gare.length === 0) && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-8 text-center">
            <Trophy className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Nessuna gara completata</h3>
            <p className="text-gray-500">I risultati saranno disponibili per le gare completate</p>
            <p className="text-xs text-gray-400 mt-2">Controlla la console per i dettagli di debug</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
