import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Save, Calculator, Trophy } from 'lucide-react';
import { ScoreCard } from './ScoreCard';
import { ClassificheSection } from './ClassificheSection';
import { calculateResults } from './utils/scoreCalculations';

interface RisultatiFormProps {
  garaId: string;
  onClose: () => void;
  onSuccess: () => void;
}

// Funzione per calcolare l'handicap giocato in base al numero di buche
const calculateHandicapGiocato = (handicapUfficiale: number, numeroBuche: number): number => {
  if (numeroBuche === 18) {
    return handicapUfficiale;
  } else if (numeroBuche === 9) {
    // Per 9 buche, l'handicap è la metà di quello a 18 buche
    return Math.round((handicapUfficiale / 2) * 10) / 10; // Arrotonda a 1 decimale
  } else {
    // Per altri numeri di buche, calcola proporzionalmente
    return Math.round((handicapUfficiale * numeroBuche / 18) * 10) / 10;
  }
};

export const RisultatiForm = ({ garaId, onClose, onSuccess }: RisultatiFormProps) => {
  const [scores, setScores] = useState<{ [key: string]: { [buca: number]: number } }>({});
  const [handicapsGiocati, setHandicapsGiocati] = useState<{ [key: string]: number }>({});
  const [handicapsCalcolati, setHandicapsCalcolati] = useState<{ [key: string]: number }>({});
  const [showClassifiche, setShowClassifiche] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: garaData } = useQuery({
    queryKey: ['gara-risultati', garaId],
    queryFn: async () => {
      const { data } = await supabase
        .from('gare')
        .select(`
          *,
          percorsi (
            nome, 
            par,
            buche (numero, par, handicap_index)
          ),
          iscrizioni (
            id,
            soci (id, nome, cognome, handicap, sesso)
          )
        `)
        .eq('id', garaId)
        .single();
      return data;
    },
  });

  // Carica i risultati esistenti separatamente
  const { data: risultatiEsistenti } = useQuery({
    queryKey: ['risultati-esistenti', garaId],
    queryFn: async () => {
      if (!garaData?.iscrizioni) return [];
      
      const iscrizioniIds = garaData.iscrizioni.map((i: any) => i.id);
      
      const { data } = await supabase
        .from('risultati')
        .select(`
          id,
          iscrizione_id,
          handicap_giocato,
          punteggio_lordo,
          punteggio_netto,
          punti_stableford,
          score_buche (buca_numero, colpi, punti_stableford)
        `)
        .in('iscrizione_id', iscrizioniIds);
      
      return data || [];
    },
    enabled: !!garaData?.iscrizioni,
  });

  // Calcola e memorizza gli handicap calcolati quando cambiano i dati della gara
  useEffect(() => {
    if (garaData?.iscrizioni && garaData.numero_buche) {
      const calculatedHandicaps: { [key: string]: number } = {};
      
      garaData.iscrizioni.forEach((iscrizione: any) => {
        const handicapCalcolato = calculateHandicapGiocato(
          iscrizione.soci.handicap || 54,
          garaData.numero_buche
        );
        calculatedHandicaps[iscrizione.id] = handicapCalcolato;
      });
      
      setHandicapsCalcolati(calculatedHandicaps);
      
      // Inizializza immediatamente gli handicap giocati con i valori calcolati
      // ma solo se non ci sono risultati esistenti
      if (!risultatiEsistenti || risultatiEsistenti.length === 0) {
        setHandicapsGiocati(calculatedHandicaps);
      }
    }
  }, [garaData, risultatiEsistenti]);

  // Carica gli score esistenti e aggiorna gli handicap solo se ci sono valori salvati
  useEffect(() => {
    if (risultatiEsistenti && risultatiEsistenti.length > 0) {
      const existingScores: { [key: string]: { [buca: number]: number } } = {};
      const existingHandicaps: { [key: string]: number } = {};
      
      risultatiEsistenti.forEach((risultato: any) => {
        if (risultato.score_buche) {
          existingScores[risultato.iscrizione_id] = {};
          risultato.score_buche.forEach((score: any) => {
            existingScores[risultato.iscrizione_id][score.buca_numero] = score.colpi;
          });
        }
        if (risultato.handicap_giocato !== null && risultato.handicap_giocato !== undefined) {
          existingHandicaps[risultato.iscrizione_id] = risultato.handicap_giocato;
        }
      });
      
      setScores(existingScores);
      
      // Aggiorna gli handicap giocati con quelli esistenti
      if (Object.keys(existingHandicaps).length > 0) {
        setHandicapsGiocati(prev => {
          const newHandicaps = { ...prev };
          // Per ogni iscrizione, usa l'handicap salvato se esiste, altrimenti quello calcolato
          Object.keys(handicapsCalcolati).forEach(iscrizioneId => {
            if (existingHandicaps[iscrizioneId] !== undefined) {
              newHandicaps[iscrizioneId] = existingHandicaps[iscrizioneId];
            } else {
              newHandicaps[iscrizioneId] = handicapsCalcolati[iscrizioneId];
            }
          });
          return newHandicaps;
        });
      }
    }
  }, [risultatiEsistenti, handicapsCalcolati]);

  const salvaRisultatiMutation = useMutation({
    mutationFn: async (data: { iscrizioneId: string; scores: { [buca: number]: number }; handicapGiocato: number }) => {
      console.log('Salvando risultati per iscrizione:', data.iscrizioneId);
      
      if (!garaData) throw new Error('Dati gara non disponibili');
      
      // Calcola i risultati
      const risultatiCalcolati = calculateResults(
        data.scores,
        data.handicapGiocato,
        garaData.percorsi.buche,
        garaData.formula || 'Stableford'
      );
      
      console.log('Risultati calcolati:', risultatiCalcolati);

      // Verifica se esiste già un risultato per questa iscrizione
      const { data: esisteRisultato } = await supabase
        .from('risultati')
        .select('id')
        .eq('iscrizione_id', data.iscrizioneId)
        .maybeSingle();

      let risultatoId: string;

      if (esisteRisultato) {
        // Aggiorna il risultato esistente
        const { data: risultatoAggiornato, error: errorUpdate } = await supabase
          .from('risultati')
          .update({
            handicap_giocato: data.handicapGiocato,
            punteggio_lordo: risultatiCalcolati.punteggioLordo,
            punteggio_netto: risultatiCalcolati.punteggioNetto,
            punti_stableford: garaData.formula === 'Stableford' ? risultatiCalcolati.puntiStableford : null
          })
          .eq('id', esisteRisultato.id)
          .select('id')
          .single();

        if (errorUpdate) throw errorUpdate;
        risultatoId = risultatoAggiornato.id;

        // Elimina gli score per buca esistenti
        await supabase
          .from('score_buche')
          .delete()
          .eq('risultato_id', risultatoId);
      } else {
        // Crea nuovo risultato
        const { data: nuovoRisultato, error: errorInsert } = await supabase
          .from('risultati')
          .insert({
            iscrizione_id: data.iscrizioneId,
            handicap_giocato: data.handicapGiocato,
            punteggio_lordo: risultatiCalcolati.punteggioLordo,
            punteggio_netto: risultatiCalcolati.punteggioNetto,
            punti_stableford: garaData.formula === 'Stableford' ? risultatiCalcolati.puntiStableford : null
          })
          .select('id')
          .single();

        if (errorInsert) throw errorInsert;
        risultatoId = nuovoRisultato.id;
      }

      // Inserisci gli score per buca
      const scoreBuche = Object.entries(data.scores).map(([buca, colpi]) => ({
        risultato_id: risultatoId,
        buca_numero: parseInt(buca),
        colpi: colpi,
        punti_stableford: garaData.formula === 'Stableford' ? (risultatiCalcolati.scorePerBuca[parseInt(buca)]?.punti || 0) : 0
      }));

      const { error: errorScoreBuche } = await supabase
        .from('score_buche')
        .insert(scoreBuche);

      if (errorScoreBuche) throw errorScoreBuche;

      return risultatoId;
    },
    onSuccess: () => {
      toast({
        title: "Successo",
        description: "Risultati salvati con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['gara-risultati', garaId] });
      queryClient.invalidateQueries({ queryKey: ['risultati-esistenti', garaId] });
      queryClient.invalidateQueries({ queryKey: ['classifiche', garaId] });
    },
    onError: (error) => {
      console.error('Errore nel salvare i risultati:', error);
      toast({
        title: "Errore",
        description: "Errore nel salvare i risultati",
        variant: "destructive",
      });
    },
  });

  const handleScoreChange = (iscrizioneId: string, buca: number, colpi: number) => {
    setScores(prev => ({
      ...prev,
      [iscrizioneId]: {
        ...prev[iscrizioneId],
        [buca]: colpi
      }
    }));
  };

  const handleHandicapChange = (iscrizioneId: string, handicap: number) => {
    setHandicapsGiocati(prev => ({
      ...prev,
      [iscrizioneId]: handicap
    }));
  };

  const handleSalvaRisultati = (iscrizioneId: string) => {
    const scoreGiocatore = scores[iscrizioneId] || {};
    const handicapGiocato = handicapsGiocati[iscrizioneId] ?? 0;
    
    if (Object.keys(scoreGiocatore).length === 0) {
      toast({
        title: "Attenzione",
        description: "Inserisci almeno uno score prima di salvare",
        variant: "destructive",
      });
      return;
    }

    salvaRisultatiMutation.mutate({
      iscrizioneId,
      scores: scoreGiocatore,
      handicapGiocato
    });
  };

  if (!garaData) {
    return <div>Caricamento...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">{garaData.nome}</h3>
          <p className="text-sm text-gray-600">
            {garaData.percorsi?.nome} - {garaData.formula} - {garaData.numero_buche} buche
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant={showClassifiche ? "default" : "outline"} 
            onClick={() => setShowClassifiche(!showClassifiche)}
          >
            <Trophy className="h-4 w-4 mr-1" />
            {showClassifiche ? "Nascondi" : "Mostra"} Classifiche
          </Button>
          <Button variant="outline" onClick={onClose}>
            Chiudi
          </Button>
        </div>
      </div>

      {showClassifiche && (
        <ClassificheSection 
          garaId={garaId} 
          formula={garaData.formula || 'Stableford'} 
        />
      )}

      <div className="space-y-4">
        {garaData.iscrizioni?.map((iscrizione: any) => {
          const handicapCalcolato = handicapsCalcolati[iscrizione.id] || 0;
          const handicapGiocato = handicapsGiocati[iscrizione.id] ?? handicapCalcolato;
          
          console.log(`Handicap per ${iscrizione.soci.nome}:`, {
            handicapUfficiale: iscrizione.soci.handicap,
            numeroBuche: garaData.numero_buche,
            handicapCalcolato: handicapCalcolato,
            handicapGiocato: handicapGiocato
          });
          
          return (
            <Card key={iscrizione.id}>
              <CardHeader>
                <CardTitle className="text-base">
                  {iscrizione.soci.nome} {iscrizione.soci.cognome}
                  <span className="text-sm font-normal text-gray-600 ml-2">
                    (HCP Ufficiale: {iscrizione.soci.handicap})
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div>
                    <Label htmlFor={`handicap-${iscrizione.id}`}>
                      Handicap Giocato ({garaData.numero_buche} buche)
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        id={`handicap-${iscrizione.id}`}
                        type="number"
                        step="0.1"
                        value={handicapGiocato}
                        onChange={(e) => handleHandicapChange(iscrizione.id, parseFloat(e.target.value) || 0)}
                        className="w-24"
                      />
                      <span className="text-xs text-gray-500">
                        (Calcolato: {handicapCalcolato})
                      </span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleSalvaRisultati(iscrizione.id)}
                    disabled={salvaRisultatiMutation.isPending}
                  >
                    <Save className="h-4 w-4 mr-1" />
                    Salva
                  </Button>
                </div>

                <ScoreCard
                  iscrizioneId={iscrizione.id}
                  buche={garaData.percorsi.buche}
                  scores={scores[iscrizione.id] || {}}
                  handicapGiocato={handicapGiocato}
                  formula={garaData.formula || 'Stableford'}
                  onScoreChange={handleScoreChange}
                />
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
