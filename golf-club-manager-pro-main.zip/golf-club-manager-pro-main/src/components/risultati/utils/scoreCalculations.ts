
interface BucaInfo {
  numero: number;
  par: number;
  handicap_index: number;
}

interface ScorePerBuca {
  lordo: number;
  netto: number;
  punti: number;
}

interface RisultatiCalcolati {
  punteggioLordo: number;
  punteggioNetto: number;
  puntiStableford: number;
  scorePerBuca: { [buca: number]: ScorePerBuca };
}

export const calculateResults = (
  scores: { [buca: number]: number },
  handicapGiocato: number,
  buche: BucaInfo[],
  formula: string
): RisultatiCalcolati => {
  const risultati: RisultatiCalcolati = {
    punteggioLordo: 0,
    punteggioNetto: 0,
    puntiStableford: 0,
    scorePerBuca: {}
  };

  if (!buche || buche.length === 0) return risultati;

  console.log('Calcolo risultati con handicap giocato:', handicapGiocato);
  console.log('Numero buche:', buche.length);

  // Ordina le buche per handicap index per distribuire i colpi
  const bucheOrdinate = [...buche].sort((a, b) => a.handicap_index - b.handicap_index);
  
  // Calcola la distribuzione dei colpi di handicap
  const colpiPerBuca: { [numero: number]: number } = {};
  
  // Inizializza tutti a 0
  buche.forEach(buca => {
    colpiPerBuca[buca.numero] = 0;
  });
  
  // Distribuisci i colpi base (handicap / numero_buche)
  const colpiBase = Math.floor(handicapGiocato / buche.length);
  buche.forEach(buca => {
    colpiPerBuca[buca.numero] = colpiBase;
  });
  
  // Distribuisci i colpi rimanenti partendo dalle buche con handicap index più basso
  const colpiRimanenti = handicapGiocato % buche.length;
  console.log('Colpi base per buca:', colpiBase);
  console.log('Colpi rimanenti da distribuire:', colpiRimanenti);
  
  for (let i = 0; i < colpiRimanenti; i++) {
    const buca = bucheOrdinate[i];
    if (buca) {
      colpiPerBuca[buca.numero]++;
    }
  }

  console.log('Distribuzione colpi per buca:', colpiPerBuca);

  // Calcola i risultati per ogni buca
  buche.forEach(buca => {
    const colpi = scores[buca.numero];
    if (colpi && colpi > 0) {
      const colpiHandicap = colpiPerBuca[buca.numero] || 0;
      const scoreLordo = colpi;
      const scoreNetto = colpi - colpiHandicap;
      
      console.log(`Buca ${buca.numero}: ${colpi} colpi - ${colpiHandicap} handicap = ${scoreNetto} netto (par ${buca.par})`);
      
      let punti = 0;
      
      if (formula === 'Stableford') {
        // Sistema Stableford: 2 punti per il par, +1 per ogni colpo sotto, -1 per ogni colpo sopra
        const differenzaDalPar = scoreNetto - buca.par;
        punti = Math.max(0, 2 - differenzaDalPar);
        console.log(`Buca ${buca.numero}: differenza dal par = ${differenzaDalPar}, punti = ${punti}`);
      } else if (formula === 'Medal') {
        // Medal: si conta il punteggio netto
        punti = scoreNetto;
      }
      
      risultati.scorePerBuca[buca.numero] = {
        lordo: scoreLordo,
        netto: scoreNetto,
        punti: punti
      };
      
      risultati.punteggioLordo += scoreLordo;
      risultati.punteggioNetto += scoreNetto;
      
      if (formula === 'Stableford') {
        risultati.puntiStableford += punti;
      }
    }
  });

  // Per Medal, i punti Stableford sono uguali al punteggio netto
  if (formula === 'Medal') {
    risultati.puntiStableford = risultati.punteggioNetto;
  }

  console.log('Risultati finali:', risultati);
  return risultati;
};

export const calcolaClassifica = (risultati: any[], formula: string) => {
  return risultati.sort((a, b) => {
    if (formula === 'Stableford') {
      // Stableford: più punti = meglio
      return (b.punti_stableford || 0) - (a.punti_stableford || 0);
    } else {
      // Medal: meno colpi = meglio
      return (a.punteggio_netto || 999) - (b.punteggio_netto || 999);
    }
  }).map((risultato, index) => ({
    ...risultato,
    posizione: index + 1
  }));
};
