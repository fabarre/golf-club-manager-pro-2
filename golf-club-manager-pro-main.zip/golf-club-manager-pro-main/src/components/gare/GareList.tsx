import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Calendar, Users, Trophy, Edit, Eye, Euro, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { GareForm } from './GareForm';
import { GareStatusSelect } from './GareStatusSelect';
import { GareIscrizioni } from './GareIscrizioni';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import type { Database } from '@/integrations/supabase/types';

type StatoGara = Database['public']['Enums']['stato_gara'];

export const GareList = () => {
  const [showForm, setShowForm] = useState(false);
  const [editingGara, setEditingGara] = useState<string | null>(null);
  const [showIscrizioni, setShowIscrizioni] = useState(false);
  const [selectedGaraId, setSelectedGaraId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: gare, refetch } = useQuery({
    queryKey: ['gare'],
    queryFn: async () => {
      const { data } = await supabase
        .from('gare')
        .select(`
          *,
          percorsi (nome),
          iscrizioni (id, pagato, importo_dovuto)
        `)
        .order('data', { ascending: true });
      return data || [];
    },
  });

  const updateStatoMutation = useMutation({
    mutationFn: async ({ garaId, nuovoStato }: { garaId: string; nuovoStato: StatoGara }) => {
      const { error } = await supabase
        .from('gare')
        .update({ stato: nuovoStato })
        .eq('id', garaId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Successo",
        description: "Stato della gara aggiornato con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['gare'] });
    },
    onError: (error) => {
      console.error('Errore nell\'aggiornare lo stato:', error);
      toast({
        title: "Errore",
        description: "Errore nell'aggiornare lo stato della gara",
        variant: "destructive",
      });
    },
  });

  const deleteGaraMutation = useMutation({
    mutationFn: async (garaId: string) => {
      const { error } = await supabase
        .from('gare')
        .delete()
        .eq('id', garaId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Successo",
        description: "Gara eliminata con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['gare'] });
    },
    onError: (error) => {
      console.error('Errore nell\'eliminare la gara:', error);
      toast({
        title: "Errore",
        description: "Errore nell'eliminare la gara",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (stato: string) => {
    switch (stato) {
      case 'Programmata': return 'default';
      case 'In corso': return 'secondary';
      case 'Completata': return 'outline';
      case 'Annullata': return 'destructive';
      default: return 'default';
    }
  };

  const canEditGara = (gara: any) => {
    return gara.stato !== 'Completata' && gara.stato !== 'In corso';
  };

  const canDeleteGara = (gara: any) => {
    if (gara.stato === 'Completata' || gara.stato === 'In corso') {
      return false;
    }
    return !gara.iscrizioni || gara.iscrizioni.length === 0;
  };

  const getDeleteMessage = (gara: any) => {
    if (gara.stato === 'Completata') {
      return "Non è possibile eliminare una gara completata.";
    }
    if (gara.stato === 'In corso') {
      return "Non è possibile eliminare una gara in corso.";
    }
    if (gara.iscrizioni && gara.iscrizioni.length > 0) {
      return `Non è possibile eliminare una gara con ${gara.iscrizioni.length} iscritti. Rimuovi prima tutte le iscrizioni.`;
    }
    return `Sei sicuro di voler eliminare la gara "${gara.nome}"? Questa azione non può essere annullata.`;
  };

  const handleEditGara = (garaId: string) => {
    setEditingGara(garaId);
    setShowForm(true);
  };

  const handleDeleteGara = (garaId: string) => {
    deleteGaraMutation.mutate(garaId);
  };

  const handleShowIscrizioni = (garaId: string) => {
    setSelectedGaraId(garaId);
    setShowIscrizioni(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingGara(null);
  };

  const handleCloseIscrizioni = () => {
    setShowIscrizioni(false);
    setSelectedGaraId(null);
  };

  const handleFormSuccess = () => {
    refetch();
  };

  const handleStatusChange = (garaId: string, nuovoStato: StatoGara) => {
    updateStatoMutation.mutate({ garaId, nuovoStato });
  };

  const calcolaTotali = (gara: any) => {
    if (!gara.iscrizioni) return { incassato: 0, daIncassare: 0 };
    
    const incassato = gara.iscrizioni
      .filter((i: any) => i.pagato)
      .reduce((sum: number, i: any) => sum + (i.importo_dovuto || 0), 0);
    
    const daIncassare = gara.iscrizioni
      .filter((i: any) => !i.pagato)
      .reduce((sum: number, i: any) => sum + (i.importo_dovuto || 0), 0);
    
    return { incassato, daIncassare };
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gare e Tornei</h2>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Nuova Gara
        </Button>
      </div>

      {showForm && (
        <Dialog open={showForm} onOpenChange={handleCloseForm}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingGara ? 'Modifica Gara' : 'Nuova Gara'}</DialogTitle>
            </DialogHeader>
            <GareForm 
              garaId={editingGara || undefined}
              onClose={handleCloseForm}
              onSuccess={handleFormSuccess}
            />
          </DialogContent>
        </Dialog>
      )}

      {showIscrizioni && selectedGaraId && (
        <Dialog open={showIscrizioni} onOpenChange={handleCloseIscrizioni}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Gestione Iscrizioni</DialogTitle>
            </DialogHeader>
            <GareIscrizioni 
              garaId={selectedGaraId}
              onClose={handleCloseIscrizioni}
            />
          </DialogContent>
        </Dialog>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {gare?.map((gara) => {
          const totali = calcolaTotali(gara);
          const canEdit = canEditGara(gara);
          const canDelete = canDeleteGara(gara);
          
          return (
            <Card key={gara.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{gara.nome}</CardTitle>
                  <GareStatusSelect
                    currentStatus={gara.stato}
                    onStatusChange={(nuovoStato) => handleStatusChange(gara.id, nuovoStato)}
                    disabled={updateStatoMutation.isPending}
                  />
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <span>
                    {format(new Date(gara.data), 'dd MMMM yyyy', { locale: it })}
                  </span>
                </div>
                
                {gara.orario_inizio && gara.orario_fine && (
                  <div className="text-sm text-gray-600">
                    <span>
                      Orario: {gara.orario_inizio} - {gara.orario_fine}
                    </span>
                  </div>
                )}
                
                {gara.percorsi && (
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Trophy className="h-4 w-4" />
                    <span>{gara.percorsi.nome}</span>
                  </div>
                )}

                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Users className="h-4 w-4" />
                  <span>{gara.iscrizioni?.length || 0} iscritti</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-600">Formula:</span>
                    <div className="font-medium">{gara.formula}</div>
                  </div>
                  <div>
                    <span className="text-gray-600">Buche:</span>
                    <div className="font-medium">{gara.numero_buche}</div>
                  </div>
                </div>

                <div className="text-sm border-t pt-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center space-x-1">
                      <Euro className="h-3 w-3 text-green-600" />
                      <div>
                        <div className="text-xs text-gray-600">Incassato:</div>
                        <div className="font-medium text-green-600">€{totali.incassato.toFixed(2)}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Euro className="h-3 w-3 text-orange-600" />
                      <div>
                        <div className="text-xs text-gray-600">Da incassare:</div>
                        <div className="font-medium text-orange-600">€{totali.daIncassare.toFixed(2)}</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col space-y-2 pt-2">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="w-full"
                    onClick={() => handleEditGara(gara.id)}
                    disabled={!canEdit}
                    title={!canEdit ? (gara.stato === 'Completata' ? "Non è possibile modificare una gara completata" : "Non è possibile modificare una gara in corso") : ""}
                  >
                    <Edit className="h-3 w-3 mr-1" />
                    Modifica
                  </Button>
                  <Button 
                    size="sm" 
                    className="w-full"
                    onClick={() => handleShowIscrizioni(gara.id)}
                  >
                    <Eye className="h-3 w-3 mr-1" />
                    Gestisci Iscrizioni
                  </Button>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        className="w-full"
                        disabled={!canDelete}
                        title={!canDelete ? getDeleteMessage(gara) : ""}
                      >
                        <Trash2 className="h-3 w-3 mr-1" />
                        Elimina
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Conferma eliminazione</AlertDialogTitle>
                        <AlertDialogDescription>
                          {getDeleteMessage(gara)}
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Annulla</AlertDialogCancel>
                        {canDelete && (
                          <AlertDialogAction
                            onClick={() => handleDeleteGara(gara.id)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Elimina
                          </AlertDialogAction>
                        )}
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {(!gare || gare.length === 0) && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-8 text-center">
            <Trophy className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Nessuna gara trovata</h3>
            <p className="text-gray-500 mb-4">Inizia creando la tua prima gara o torneo</p>
            <Button onClick={() => setShowForm(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Nuova Gara
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
