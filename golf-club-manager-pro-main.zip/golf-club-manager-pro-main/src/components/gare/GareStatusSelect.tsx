
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import type { Database } from '@/integrations/supabase/types';

type StatoGara = Database['public']['Enums']['stato_gara'];

interface GareStatusSelectProps {
  currentStatus: StatoGara | null;
  onStatusChange: (status: StatoGara) => void;
  disabled?: boolean;
}

export const GareStatusSelect = ({ currentStatus, onStatusChange, disabled }: GareStatusSelectProps) => {
  const getStatusColor = (stato: string | null) => {
    switch (stato) {
      case 'Programmata': return 'default';
      case 'In corso': return 'secondary';
      case 'Completata': return 'outline';
      case 'Annullata': return 'destructive';
      default: return 'default';
    }
  };

  return (
    <Select
      value={currentStatus || 'Programmata'}
      onValueChange={(value) => onStatusChange(value as StatoGara)}
      disabled={disabled}
    >
      <SelectTrigger className="w-auto border-none p-0 h-auto">
        <Badge variant={getStatusColor(currentStatus)}>
          {currentStatus || 'Programmata'}
        </Badge>
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="Programmata">Programmata</SelectItem>
        <SelectItem value="In corso">In corso</SelectItem>
        <SelectItem value="Completata">Completata</SelectItem>
        <SelectItem value="Annullata">Annullata</SelectItem>
      </SelectContent>
    </Select>
  );
};
