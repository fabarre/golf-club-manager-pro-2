import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { X, Save, Users, Euro, UserCheck, UserX } from 'lucide-react';

interface GareIscrizioniProps {
  garaId: string;
  onClose: () => void;
}

interface SocioIscrizione {
  id: string;
  nome: string;
  cognome: string;
  sesso: 'M' | 'F' | null;
  iscritto_circolo: boolean;
  circolo_appartenenza: string | null;
  senior: boolean;
  stato: string;
  isIscritto: boolean;
  iscrizioneId?: string;
  pagato: boolean;
  importo_dovuto: number;
  importo_pagato: number;
}

export const GareIscrizioni = ({ garaId, onClose }: GareIscrizioniProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [sociConIscrizioni, setSociConIscrizioni] = useState<SocioIscrizione[]>([]);
  const [totaleIncasso, setTotaleIncasso] = useState(0);
  const [totaleDaIncassare, setTotaleDaIncassare] = useState(0);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [socioToDeselect, setSocioToDeselect] = useState<SocioIscrizione | null>(null);

  console.log('GareIscrizioni component loaded with garaId:', garaId);

  // Carica i dati della gara
  const { data: gara, isLoading: garaLoading } = useQuery({
    queryKey: ['gara', garaId],
    queryFn: async () => {
      console.log('Loading gara data for ID:', garaId);
      const { data, error } = await supabase
        .from('gare')
        .select('*')
        .eq('id', garaId)
        .single();
      
      if (error) {
        console.error('Error loading gara:', error);
        throw error;
      }
      console.log('Gara loaded:', data);
      return data;
    },
  });

  // Carica tutti i soci
  const { data: soci, isLoading: sociLoading, error: sociError } = useQuery({
    queryKey: ['soci'],
    queryFn: async () => {
      console.log('Loading all soci data...');
      const { data, error } = await supabase
        .from('soci')
        .select('id, nome, cognome, sesso, iscritto_circolo, circolo_appartenenza, senior, stato')
        .order('cognome');
      
      if (error) {
        console.error('Error loading soci:', error);
        throw error;
      }
      console.log('All soci loaded:', data?.length, 'total members');
      return data || [];
    },
  });

  // Carica le iscrizioni esistenti
  const { data: iscrizioni, isLoading: iscrizioniLoading } = useQuery({
    queryKey: ['iscrizioni', garaId],
    queryFn: async () => {
      console.log('Loading existing iscrizioni for gara:', garaId);
      const { data, error } = await supabase
        .from('iscrizioni')
        .select('*')
        .eq('gara_id', garaId);
      
      if (error) {
        console.error('Error loading iscrizioni:', error);
        throw error;
      }
      console.log('Iscrizioni loaded:', data?.length, 'entries');
      return data || [];
    },
  });

  // Calcola l'importo dovuto per un socio
  const calcolaImportoDovuto = (socio: any): number => {
    if (!gara) return 0;
    
    const isUomo = socio.sesso === 'M';
    const isIscritto = socio.iscritto_circolo;
    
    if (isUomo && isIscritto) return gara.costo_iscritto_uomo || 0;
    if (!isUomo && isIscritto) return gara.costo_iscritto_donna || 0;
    if (isUomo && !isIscritto) return gara.costo_non_iscritto_uomo || 0;
    if (!isUomo && !isIscritto) return gara.costo_non_iscritto_donna || 0;
    
    return 0;
  };

  // Aggiorna i totali automaticamente
  const aggiornaTotali = (sociData: SocioIscrizione[]) => {
    const incasso = sociData
      .filter(s => s.isIscritto && s.pagato)
      .reduce((sum, s) => sum + s.importo_dovuto, 0);
    
    const daIncassare = sociData
      .filter(s => s.isIscritto && !s.pagato)
      .reduce((sum, s) => sum + s.importo_dovuto, 0);
    
    setTotaleIncasso(incasso);
    setTotaleDaIncassare(daIncassare);
  };

  // Combina soci e iscrizioni
  useEffect(() => {
    console.log('Combining soci and iscrizioni...');
    console.log('Soci available:', soci?.length);
    console.log('Iscrizioni available:', iscrizioni?.length);
    console.log('Gara available:', !!gara);
    
    if (soci && iscrizioni && gara) {
      const sociConIscrizioniData = soci.map(socio => {
        const iscrizione = iscrizioni.find(i => i.socio_id === socio.id);
        const importoDovuto = calcolaImportoDovuto(socio);
        
        return {
          ...socio,
          isIscritto: !!iscrizione,
          iscrizioneId: iscrizione?.id,
          pagato: iscrizione?.pagato || false,
          importo_dovuto: importoDovuto,
          importo_pagato: iscrizione?.importo_pagato || 0,
        };
      });
      
      console.log('Combined data:', sociConIscrizioniData.length, 'members processed');
      setSociConIscrizioni(sociConIscrizioniData);
      aggiornaTotali(sociConIscrizioniData);
    }
  }, [soci, iscrizioni, gara]);

  // Mutation per salvare le iscrizioni
  const saveIscrizioniMutation = useMutation({
    mutationFn: async (sociSelezionati: SocioIscrizione[]) => {
      // Elimina le iscrizioni non più selezionate
      const iscrizioniDaEliminare = iscrizioni?.filter(
        i => !sociSelezionati.find(s => s.id === i.socio_id)
      ) || [];
      
      for (const iscrizione of iscrizioniDaEliminare) {
        await supabase.from('iscrizioni').delete().eq('id', iscrizione.id);
      }
      
      // Inserisci o aggiorna le iscrizioni selezionate
      for (const socio of sociSelezionati) {
        const iscrizioneData = {
          gara_id: garaId,
          socio_id: socio.id,
          importo_dovuto: socio.importo_dovuto,
          importo_pagato: socio.pagato ? socio.importo_dovuto : 0,
          pagato: socio.pagato,
        };
        
        if (socio.iscrizioneId) {
          // Aggiorna iscrizione esistente
          await supabase
            .from('iscrizioni')
            .update(iscrizioneData)
            .eq('id', socio.iscrizioneId);
        } else {
          // Crea nuova iscrizione
          await supabase
            .from('iscrizioni')
            .insert(iscrizioneData);
        }
      }
      
      // Aggiorna l'incasso totale della gara
      const nuovoIncassoTotale = sociSelezionati
        .filter(s => s.pagato)
        .reduce((sum, s) => sum + s.importo_dovuto, 0);
      
      await supabase
        .from('gare')
        .update({ incasso_totale: nuovoIncassoTotale })
        .eq('id', garaId);
    },
    onSuccess: () => {
      toast({
        title: "Successo",
        description: "Iscrizioni salvate con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['iscrizioni', garaId] });
      queryClient.invalidateQueries({ queryKey: ['gare'] });
      onClose();
    },
    onError: (error) => {
      console.error('Errore nel salvare le iscrizioni:', error);
      toast({
        title: "Errore",
        description: "Errore nel salvare le iscrizioni",
        variant: "destructive",
      });
    },
  });

  const handleIscrizioneToggle = (socioId: string, isIscritto: boolean) => {
    console.log('Toggling iscrizione for socio:', socioId, 'to:', isIscritto);
    
    if (!isIscritto) {
      // Deiscrizione - controlla se ha pagato
      const socio = sociConIscrizioni.find(s => s.id === socioId);
      if (socio && socio.pagato) {
        setSocioToDeselect(socio);
        setShowConfirmDialog(true);
        return;
      }
    }
    
    // Procedi con l'iscrizione/deiscrizione
    const newSociData = sociConIscrizioni.map(socio => 
      socio.id === socioId 
        ? { ...socio, isIscritto, pagato: isIscritto ? socio.pagato : false }
        : socio
    );
    
    setSociConIscrizioni(newSociData);
    aggiornaTotali(newSociData);
  };

  const handleConfirmDeselect = () => {
    if (!socioToDeselect) return;
    
    const newSociData = sociConIscrizioni.map(socio => 
      socio.id === socioToDeselect.id 
        ? { ...socio, isIscritto: false, pagato: false }
        : socio
    );
    
    setSociConIscrizioni(newSociData);
    aggiornaTotali(newSociData);
    
    toast({
      title: "Deiscrizione effettuata",
      description: `${socioToDeselect.nome} ${socioToDeselect.cognome} è stato disiscritto. Ricordati di restituire la quota di €${socioToDeselect.importo_dovuto.toFixed(2)}`,
      variant: "destructive",
    });
    
    setShowConfirmDialog(false);
    setSocioToDeselect(null);
  };

  const handlePagamentoToggle = (socioId: string, pagato: boolean) => {
    console.log('Toggling pagamento for socio:', socioId, 'to:', pagato);
    
    const newSociData = sociConIscrizioni.map(socio => 
      socio.id === socioId 
        ? { ...socio, pagato }
        : socio
    );
    
    setSociConIscrizioni(newSociData);
    aggiornaTotali(newSociData);
  };

  const handleSave = () => {
    const sociIscritti = sociConIscrizioni.filter(s => s.isIscritto);
    console.log('Saving iscrizioni for', sociIscritti.length, 'soci');
    saveIscrizioniMutation.mutate(sociIscritti);
  };

  const isLoading = garaLoading || sociLoading || iscrizioniLoading;

  if (sociError) {
    console.error('Error loading soci:', sociError);
  }

  if (isLoading) {
    return (
      <Card className="w-full max-w-6xl mx-auto">
        <CardContent className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          <span className="ml-2">Caricamento dati...</span>
        </CardContent>
      </Card>
    );
  }

  if (!gara) {
    return (
      <Card className="w-full max-w-6xl mx-auto">
        <CardContent className="flex items-center justify-center py-8">
          <span>Errore nel caricamento della gara</span>
        </CardContent>
      </Card>
    );
  }

  if (!soci || soci.length === 0) {
    return (
      <Card className="w-full max-w-6xl mx-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Users className="h-5 w-5" />
            <span>Gestione Iscrizioni - {gara?.nome}</span>
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p>Nessun socio trovato nel database</p>
            <p className="text-sm text-gray-500 mt-2">
              Debug: Totale soci caricati: {soci?.length || 0}
            </p>
            {sociError && (
              <p className="text-red-500 text-sm mt-2">
                Errore: {sociError.message}
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Separa soci iscritti e non iscritti, ordinati per cognome
  const sociIscritti = sociConIscrizioni
    .filter(s => s.isIscritto)
    .sort((a, b) => a.cognome.localeCompare(b.cognome));
  
  const sociNonIscritti = sociConIscrizioni
    .filter(s => !s.isIscritto)
    .sort((a, b) => a.cognome.localeCompare(b.cognome));

  const sociAttivi = sociConIscrizioni.filter(s => s.stato === 'Attivo');
  const sociInattivi = sociConIscrizioni.filter(s => s.stato !== 'Attivo');

  // Componente per visualizzare un socio
  const SocioItem = ({ socio, isInIscrittiList }: { socio: SocioIscrizione, isInIscrittiList: boolean }) => (
    <div 
      className={`flex items-center justify-between p-3 border rounded-lg ${
        socio.isIscritto ? 'bg-green-50 border-green-200' : 
        socio.stato === 'Attivo' ? 'bg-white' : 'bg-gray-50 border-gray-200'
      }`}
    >
      <div className="flex items-center space-x-3">
        <Checkbox
          checked={socio.isIscritto}
          onCheckedChange={(checked) => 
            handleIscrizioneToggle(socio.id, checked as boolean)
          }
          disabled={socio.stato !== 'Attivo'}
        />
        <div>
          <div className="font-medium">
            {socio.cognome} {socio.nome}
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Badge variant={socio.sesso === 'M' ? 'default' : 'secondary'}>
              {socio.sesso === 'M' ? 'Uomo' : 'Donna'}
            </Badge>
            <Badge variant={socio.stato === 'Attivo' ? 'default' : 'secondary'}>
              {socio.stato}
            </Badge>
            {socio.senior && (
              <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                Senior
              </Badge>
            )}
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              {socio.iscritto_circolo ? 'Serenissima di Brescia' : socio.circolo_appartenenza || 'Circolo Esterno'}
            </Badge>
          </div>
        </div>
      </div>
      
      {socio.isIscritto && (
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <div className="font-medium">€{socio.importo_dovuto.toFixed(2)}</div>
            <div className="text-xs text-gray-500">Quota dovuta</div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              checked={socio.pagato}
              onCheckedChange={(checked) => 
                handlePagamentoToggle(socio.id, checked as boolean)
              }
            />
            <span className="text-sm">Pagato</span>
            {socio.pagato && <Euro className="h-4 w-4 text-green-600" />}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <>
      <Card className="w-full max-w-6xl mx-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Users className="h-5 w-5" />
            <span>Gestione Iscrizioni - {gara?.nome}</span>
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          {/* Avviso se ci sono solo soci inattivi */}
          {sociAttivi.length === 0 && sociInattivi.length > 0 && (
            <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded">
              <p className="text-orange-800 font-medium">⚠️ Attenzione</p>
              <p className="text-orange-700 text-sm">
                Tutti i soci nel database hanno stato "Inattivo". Per procedere con le iscrizioni, 
                è necessario attivare almeno un socio dalla sezione Gestione Soci.
              </p>
            </div>
          )}

          {/* Riepilogo finanziario */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">€{totaleIncasso.toFixed(2)}</div>
              <div className="text-sm text-gray-600">Incasso totale</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">€{totaleDaIncassare.toFixed(2)}</div>
              <div className="text-sm text-gray-600">Da incassare</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{sociIscritti.length}</div>
              <div className="text-sm text-gray-600">Iscritti totali</div>
            </div>
          </div>

          {/* Sezione Soci Iscritti */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <UserCheck className="h-5 w-5 mr-2 text-green-600" />
              Soci Iscritti ({sociIscritti.length})
            </h3>
            {sociIscritti.length === 0 ? (
              <div className="text-center py-4 text-gray-500 bg-gray-50 rounded-lg">
                Nessun socio iscritto alla gara
              </div>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto border rounded-lg p-2">
                {sociIscritti.map((socio) => (
                  <SocioItem key={socio.id} socio={socio} isInIscrittiList={true} />
                ))}
              </div>
            )}
          </div>

          {/* Sezione Soci Non Iscritti */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <UserX className="h-5 w-5 mr-2 text-gray-600" />
              Soci Non Iscritti ({sociNonIscritti.length})
            </h3>
            {sociNonIscritti.length === 0 ? (
              <div className="text-center py-4 text-gray-500 bg-gray-50 rounded-lg">
                Tutti i soci sono iscritti alla gara
              </div>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto border rounded-lg p-2">
                {sociNonIscritti.map((socio) => (
                  <SocioItem key={socio.id} socio={socio} isInIscrittiList={false} />
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-2 mt-6">
            <Button variant="outline" onClick={onClose}>
              Annulla
            </Button>
            <Button 
              onClick={handleSave}
              disabled={saveIscrizioniMutation.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              {saveIscrizioniMutation.isPending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Salva Iscrizioni
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Dialog di conferma per deiscrizione con pagamento */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Conferma Deiscrizione</AlertDialogTitle>
            <AlertDialogDescription>
              Il socio <strong>{socioToDeselect?.nome} {socioToDeselect?.cognome}</strong> ha già pagato 
              la quota di iscrizione di <strong>€{socioToDeselect?.importo_dovuto.toFixed(2)}</strong>.
              <br /><br />
              Procedendo con la deiscrizione:
              <ul className="list-disc list-inside mt-2">
                <li>Il socio verrà rimosso dalla gara</li>
                <li>Dovrai restituire la quota pagata di €{socioToDeselect?.importo_dovuto.toFixed(2)}</li>
                <li>L'incasso totale verrà aggiornato automaticamente</li>
              </ul>
              <br />
              Sei sicuro di voler procedere?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setShowConfirmDialog(false);
              setSocioToDeselect(null);
            }}>
              Annulla
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleConfirmDeselect}
              className="bg-red-600 hover:bg-red-700"
            >
              Conferma Deiscrizione
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
