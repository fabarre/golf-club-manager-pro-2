import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { X, Save } from 'lucide-react';
import { GareIscrizioni } from './GareIscrizioni';
import type { Database } from '@/integrations/supabase/types';

type StatoGara = Database['public']['Enums']['stato_gara'];

interface GareFormProps {
  garaId?: string;
  onClose: () => void;
  onSuccess?: () => void;
}

interface GaraFormData {
  nome: string;
  descrizione?: string;
  data: string;
  orario_inizio: string;
  orario_fine: string;
  tipo: string;
  formula: string;
  percorso_id: string;
  costo_iscritto_uomo?: number;
  costo_iscritto_donna?: number;
  costo_non_iscritto_uomo?: number;
  costo_non_iscritto_donna?: number;
  stato: StatoGara;
  note?: string;
}

export const GareForm = ({ garaId, onClose, onSuccess }: GareFormProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEdit = !!garaId;
  const [showIscrizioni, setShowIscrizioni] = useState(false);

  const form = useForm<GaraFormData>({
    defaultValues: {
      nome: '',
      descrizione: '',
      data: '',
      orario_inizio: '',
      orario_fine: '',
      tipo: 'Gara Sociale',
      formula: 'Stableford',
      percorso_id: '',
      costo_iscritto_uomo: 0,
      costo_iscritto_donna: 0,
      costo_non_iscritto_uomo: 0,
      costo_non_iscritto_donna: 0,
      stato: 'Programmata' as StatoGara,
      note: '',
    },
  });

  // Carica i percorsi disponibili
  const { data: percorsi } = useQuery({
    queryKey: ['percorsi'],
    queryFn: async () => {
      const { data } = await supabase
        .from('percorsi')
        .select('id, nome, numero_buche')
        .order('nome');
      return data || [];
    },
  });

  // Carica i dati della gara se in modalità edit
  const { data: gara, isLoading } = useQuery({
    queryKey: ['gara', garaId],
    queryFn: async () => {
      if (!garaId) return null;
      const { data } = await supabase
        .from('gare')
        .select('*')
        .eq('id', garaId)
        .single();
      return data;
    },
    enabled: !!garaId,
  });

  // Popola il form quando i dati della gara sono caricati
  useEffect(() => {
    if (gara) {
      form.reset({
        nome: gara.nome,
        descrizione: gara.descrizione || '',
        data: gara.data,
        orario_inizio: gara.orario_inizio || '',
        orario_fine: gara.orario_fine || '',
        tipo: gara.tipo || 'Gara Sociale',
        formula: gara.formula || 'Stableford',
        percorso_id: gara.percorso_id || '',
        costo_iscritto_uomo: gara.costo_iscritto_uomo || 0,
        costo_iscritto_donna: gara.costo_iscritto_donna || 0,
        costo_non_iscritto_uomo: gara.costo_non_iscritto_uomo || 0,
        costo_non_iscritto_donna: gara.costo_non_iscritto_donna || 0,
        stato: (gara.stato || 'Programmata') as StatoGara,
        note: gara.note || '',
      });
    }
  }, [gara, form]);

  // Mutation per salvare la gara
  const saveGaraMutation = useMutation({
    mutationFn: async (data: GaraFormData) => {
      // Get the selected percorso to inherit numero_buche
      const selectedPercorso = percorsi?.find(p => p.id === data.percorso_id);
      
      const garaData = {
        ...data,
        numero_buche: selectedPercorso?.numero_buche || 18, // Inherit from percorso
        costo_iscritto_uomo: data.costo_iscritto_uomo || 0,
        costo_iscritto_donna: data.costo_iscritto_donna || 0,
        costo_non_iscritto_uomo: data.costo_non_iscritto_uomo || 0,
        costo_non_iscritto_donna: data.costo_non_iscritto_donna || 0,
        percorso_id: data.percorso_id,
        orario_inizio: data.orario_inizio,
        orario_fine: data.orario_fine,
        descrizione: data.descrizione || null,
        note: data.note || null,
      };

      if (isEdit) {
        const { data: result, error } = await supabase
          .from('gare')
          .update(garaData)
          .eq('id', garaId)
          .select()
          .single();
        if (error) throw error;
        return result;
      } else {
        const { data: result, error } = await supabase
          .from('gare')
          .insert(garaData)
          .select()
          .single();
        if (error) throw error;
        return result;
      }
    },
    onSuccess: (savedGara) => {
      toast({
        title: "Successo",
        description: `Gara ${isEdit ? 'aggiornata' : 'creata'} con successo`,
      });
      queryClient.invalidateQueries({ queryKey: ['gare'] });
      
      // Se la gara è stata creata, mostra la sezione iscrizioni
      if (!isEdit && savedGara) {
        setShowIscrizioni(true);
      } else {
        onSuccess?.();
        onClose();
      }
    },
    onError: (error) => {
      console.error('Errore nel salvare la gara:', error);
      toast({
        title: "Errore",
        description: `Errore nel ${isEdit ? 'aggiornare' : 'creare'} la gara`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: GaraFormData) => {
    saveGaraMutation.mutate(data);
  };

  const handleIscrizioniClose = () => {
    setShowIscrizioni(false);
    onSuccess?.();
    onClose();
  };

  if (isLoading) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
        </CardContent>
      </Card>
    );
  }

  if (showIscrizioni && garaId) {
    return <GareIscrizioni garaId={garaId} onClose={handleIscrizioniClose} />;
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>{isEdit ? 'Modifica Gara' : 'Nuova Gara'}</CardTitle>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="nome"
                rules={{ required: "Il nome è obbligatorio" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome Gara *</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Nome della gara" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="data"
                rules={{ required: "La data è obbligatoria" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data *</FormLabel>
                    <FormControl>
                      <Input {...field} type="date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="tipo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleziona tipo" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Gara Sociale">Gara Sociale</SelectItem>
                        <SelectItem value="Torneo">Torneo</SelectItem>
                        <SelectItem value="Campionato">Campionato</SelectItem>
                        <SelectItem value="Louisiana">Louisiana</SelectItem>
                        <SelectItem value="Scramble">Scramble</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="formula"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Formula</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleziona formula" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Stableford">Stableford</SelectItem>
                        <SelectItem value="Medal">Medal</SelectItem>
                        <SelectItem value="Match Play">Match Play</SelectItem>
                        <SelectItem value="Four Ball">Four Ball</SelectItem>
                        <SelectItem value="Greensome">Greensome</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="percorso_id"
                rules={{ required: "Il percorso è obbligatorio" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Percorso *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleziona percorso" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {percorsi?.map((percorso) => (
                          <SelectItem key={percorso.id} value={percorso.id}>
                            {percorso.nome} ({percorso.numero_buche} buche)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="stato"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Stato</FormLabel>
                    <Select onValueChange={(value) => field.onChange(value as StatoGara)} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleziona stato" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Programmata">Programmata</SelectItem>
                        <SelectItem value="In corso">In corso</SelectItem>
                        <SelectItem value="Completata">Completata</SelectItem>
                        <SelectItem value="Annullata">Annullata</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="orario_inizio"
                rules={{ required: "L'orario di inizio è obbligatorio" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Orario Inizio *</FormLabel>
                    <FormControl>
                      <Input {...field} type="time" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="orario_fine"
                rules={{ required: "L'orario di fine è obbligatorio" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Orario Fine *</FormLabel>
                    <FormControl>
                      <Input {...field} type="time" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <FormField
                control={form.control}
                name="costo_iscritto_uomo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Costo Iscritto Uomo (€)</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        step="0.01" 
                        min="0"
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="costo_iscritto_donna"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Costo Iscritto Donna (€)</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        step="0.01" 
                        min="0"
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="costo_non_iscritto_uomo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Costo Non Iscritto Uomo (€)</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        step="0.01" 
                        min="0"
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="costo_non_iscritto_donna"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Costo Non Iscritto Donna (€)</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        step="0.01" 
                        min="0"
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="descrizione"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrizione</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Descrizione della gara"
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="note"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Note</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Note aggiuntive"
                      rows={2}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={onClose}>
                Annulla
              </Button>
              <Button 
                type="submit" 
                disabled={saveGaraMutation.isPending}
                className="bg-green-600 hover:bg-green-700"
              >
                {saveGaraMutation.isPending ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                {isEdit ? 'Aggiorna' : 'Salva'} Gara
              </Button>
              {isEdit && (
                <Button 
                  type="button"
                  variant="secondary"
                  onClick={() => setShowIscrizioni(true)}
                >
                  Gestisci Iscrizioni
                </Button>
              )}
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};
