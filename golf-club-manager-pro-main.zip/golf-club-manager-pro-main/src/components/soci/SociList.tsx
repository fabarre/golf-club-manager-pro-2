
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Edit, Trash2 } from 'lucide-react';
import { SocioForm } from './SocioForm';
import { SocioDeleteDialog } from './SocioDeleteDialog';
import { SocioStatusBadge } from './SocioStatusBadge';

export const SociList = () => {
  const [showForm, setShowForm] = useState(false);
  const [editingSocio, setEditingSocio] = useState<any>(null);
  const [deletingSocio, setDeletingSocio] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const { data: soci, refetch } = useQuery({
    queryKey: ['soci', searchTerm],
    queryFn: async () => {
      let query = supabase
        .from('soci')
        .select('*')
        .order('cognome', { ascending: true });

      if (searchTerm) {
        query = query.or(`nome.ilike.%${searchTerm}%,cognome.ilike.%${searchTerm}%`);
      }

      const { data } = await query;
      return data || [];
    },
  });

  const handleEdit = (socio: any) => {
    setEditingSocio(socio);
    setShowForm(true);
  };

  const handleDelete = (socio: any) => {
    setDeletingSocio(socio);
  };

  const handleClose = () => {
    setShowForm(false);
    setEditingSocio(null);
    refetch();
  };

  const handleDeleted = () => {
    setDeletingSocio(null);
    refetch();
  };

  const handleStatusChanged = () => {
    refetch();
  };

  if (showForm) {
    return <SocioForm socio={editingSocio} onClose={handleClose} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestione Soci</h2>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Nuovo Socio
        </Button>
      </div>

      <div className="flex items-center space-x-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Cerca soci..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {soci?.map((socio) => (
          <Card key={socio.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">
                  {socio.nome} {socio.cognome}
                </CardTitle>
                <div className="flex space-x-1">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(socio)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(socio)}>
                    <Trash2 className="h-4 w-4 text-red-600" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Handicap:</span>
                <span className="font-medium">{socio.handicap}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Tessera:</span>
                <span className="text-sm">{socio.tessera_federale || 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Stato:</span>
                <SocioStatusBadge socio={socio} onStatusChanged={handleStatusChanged} />
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Circolo:</span>
                <span className="text-sm text-right">{socio.circolo_appartenenza || 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Senior:</span>
                <Badge variant={socio.senior ? 'default' : 'secondary'} className="text-xs">
                  {socio.senior ? 'Sì' : 'No'}
                </Badge>
              </div>
              {socio.email && (
                <div className="text-sm text-gray-600 truncate">{socio.email}</div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <SocioDeleteDialog
        socio={deletingSocio}
        open={!!deletingSocio}
        onOpenChange={(open) => !open && setDeletingSocio(null)}
        onDeleted={handleDeleted}
      />
    </div>
  );
};
