
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface SocioFormProps {
  socio?: any;
  onClose: () => void;
}

export const SocioForm = ({ socio, onClose }: SocioFormProps) => {
  const [formData, setFormData] = useState({
    nome: '',
    cognome: '',
    data_nascita: '',
    indirizzo: '',
    telefono: '',
    email: '',
    handicap: 54.0,
    tessera_federale: '',
    sesso: 'M' as 'M' | 'F',
    stato: 'Attivo' as 'Attivo' | 'Sospeso' | 'Inattivo',
    iscritto_circolo: true,
    senior: false,
    circolo_appartenenza: '',
    note: '',
  });
  
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Carica la lista dei circoli italiani
  const { data: circoli } = useQuery({
    queryKey: ['circoli-italiani'],
    queryFn: async () => {
      const { data } = await supabase
        .from('circoli_italiani')
        .select('*')
        .order('nome', { ascending: true });
      return data || [];
    },
  });

  useEffect(() => {
    if (socio) {
      setFormData({
        nome: socio.nome || '',
        cognome: socio.cognome || '',
        data_nascita: socio.data_nascita || '',
        indirizzo: socio.indirizzo || '',
        telefono: socio.telefono || '',
        email: socio.email || '',
        handicap: socio.handicap || 54.0,
        tessera_federale: socio.tessera_federale || '',
        sesso: socio.sesso || 'M',
        stato: socio.stato || 'Attivo',
        iscritto_circolo: socio.iscritto_circolo ?? true,
        senior: socio.senior ?? false,
        circolo_appartenenza: socio.circolo_appartenenza || '',
        note: socio.note || '',
      });
    }
  }, [socio]);

  // Aggiorna automaticamente lo stato senior quando cambia la data di nascita
  useEffect(() => {
    if (formData.data_nascita) {
      const birthDate = new Date(formData.data_nascita);
      const today = new Date();
      const age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        setFormData(prev => ({ ...prev, senior: age - 1 >= 51 }));
      } else {
        setFormData(prev => ({ ...prev, senior: age >= 51 }));
      }
    }
  }, [formData.data_nascita]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (socio) {
        const { error } = await supabase
          .from('soci')
          .update(formData)
          .eq('id', socio.id);
        if (error) throw error;
        toast({ title: "Socio aggiornato con successo!" });
      } else {
        const { error } = await supabase
          .from('soci')
          .insert([formData]);
        if (error) throw error;
        toast({ title: "Socio creato con successo!" });
      }
      onClose();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Errore",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" onClick={onClose}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Indietro
        </Button>
        <h2 className="text-2xl font-bold">
          {socio ? 'Modifica Socio' : 'Nuovo Socio'}
        </h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Informazioni Personali</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="nome">Nome *</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="cognome">Cognome *</Label>
                <Input
                  id="cognome"
                  value={formData.cognome}
                  onChange={(e) => setFormData({ ...formData, cognome: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="data_nascita">Data di Nascita</Label>
                <Input
                  id="data_nascita"
                  type="date"
                  value={formData.data_nascita}
                  onChange={(e) => setFormData({ ...formData, data_nascita: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="sesso">Sesso</Label>
                <Select onValueChange={(value: any) => setFormData({ ...formData, sesso: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder={formData.sesso === 'M' ? 'Maschio' : 'Femmina'} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="M">Maschio</SelectItem>
                    <SelectItem value="F">Femmina</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="telefono">Telefono</Label>
                <Input
                  id="telefono"
                  value={formData.telefono}
                  onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="handicap">Handicap</Label>
                <Input
                  id="handicap"
                  type="number"
                  step="0.1"
                  value={formData.handicap}
                  onChange={(e) => setFormData({ ...formData, handicap: parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div>
                <Label htmlFor="tessera_federale">Tessera Federale</Label>
                <Input
                  id="tessera_federale"
                  value={formData.tessera_federale}
                  onChange={(e) => setFormData({ ...formData, tessera_federale: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="stato">Stato</Label>
                <Select onValueChange={(value: any) => setFormData({ ...formData, stato: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder={formData.stato} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Attivo">Attivo</SelectItem>
                    <SelectItem value="Sospeso">Sospeso</SelectItem>
                    <SelectItem value="Inattivo">Inattivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="circolo_appartenenza">Circolo di Appartenenza</Label>
                {formData.iscritto_circolo ? (
                  <Input
                    id="circolo_appartenenza"
                    value="Il nostro circolo"
                    disabled
                    className="bg-gray-100"
                  />
                ) : (
                  <Select 
                    onValueChange={(value) => setFormData({ ...formData, circolo_appartenenza: value })}
                    value={formData.circolo_appartenenza}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleziona un circolo" />
                    </SelectTrigger>
                    <SelectContent>
                      {circoli?.map((circolo) => (
                        <SelectItem key={circolo.id} value={circolo.nome}>
                          {circolo.nome} - {circolo.citta}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="indirizzo">Indirizzo</Label>
              <Input
                id="indirizzo"
                value={formData.indirizzo}
                onChange={(e) => setFormData({ ...formData, indirizzo: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="iscritto_circolo"
                  checked={formData.iscritto_circolo}
                  onCheckedChange={(checked) => {
                    setFormData({ 
                      ...formData, 
                      iscritto_circolo: checked,
                      circolo_appartenenza: checked ? '' : formData.circolo_appartenenza
                    });
                  }}
                />
                <Label htmlFor="iscritto_circolo">Appartiene al nostro Circolo</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="senior"
                  checked={formData.senior}
                  disabled={true}
                />
                <Label htmlFor="senior">Senior (automatico dai 51 anni)</Label>
              </div>
            </div>

            <div>
              <Label htmlFor="note">Note</Label>
              <Textarea
                id="note"
                value={formData.note}
                onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                rows={3}
              />
            </div>

            <div className="flex space-x-4">
              <Button type="submit" disabled={loading}>
                {loading ? 'Salvando...' : 'Salva'}
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                Annulla
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
