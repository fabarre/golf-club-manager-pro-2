
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

interface SocioDeleteDialogProps {
  socio: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onDeleted: () => void;
}

export const SocioDeleteDialog = ({ socio, open, onOpenChange, onDeleted }: SocioDeleteDialogProps) => {
  const [deleting, setDeleting] = useState(false);
  const { toast } = useToast();

  const { data: iscrizioni } = useQuery({
    queryKey: ['iscrizioni-socio', socio?.id],
    queryFn: async () => {
      if (!socio?.id) return [];
      const { data } = await supabase
        .from('iscrizioni')
        .select(`
          *,
          gare (
            nome,
            data,
            stato
          )
        `)
        .eq('socio_id', socio.id);
      return data || [];
    },
    enabled: !!socio?.id && open,
  });

  const hasActiveIscrizioni = iscrizioni && iscrizioni.length > 0;

  const handleDelete = async () => {
    if (!socio?.id || hasActiveIscrizioni) return;

    setDeleting(true);
    try {
      const { error } = await supabase
        .from('soci')
        .delete()
        .eq('id', socio.id);

      if (error) throw error;

      toast({ title: "Socio cancellato con successo!" });
      onDeleted();
      onOpenChange(false);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Errore",
        description: error.message,
      });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>
            {hasActiveIscrizioni ? 'Impossibile cancellare il socio' : 'Conferma cancellazione'}
          </AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-4">
              {hasActiveIscrizioni ? (
                <>
                  <p>
                    Impossibile cancellare il socio <strong>{socio?.nome} {socio?.cognome}</strong> 
                    perché è iscritto alle seguenti gare:
                  </p>
                  <div className="space-y-2">
                    {iscrizioni?.map((iscrizione: any) => (
                      <div key={iscrizione.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div>
                          <div className="font-medium">{iscrizione.gare?.nome}</div>
                          <div className="text-sm text-gray-600">
                            Data: {new Date(iscrizione.gare?.data).toLocaleDateString('it-IT')}
                          </div>
                        </div>
                        <Badge variant={iscrizione.gare?.stato === 'Completata' ? 'secondary' : 'default'}>
                          {iscrizione.gare?.stato}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">
                    Per cancellare questo socio, rimuovi prima le sue iscrizioni alle gare.
                  </p>
                </>
              ) : (
                <p>
                  Sei sicuro di voler cancellare il socio <strong>{socio?.nome} {socio?.cognome}</strong>? 
                  Questa azione non può essere annullata.
                </p>
              )}
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>
            {hasActiveIscrizioni ? 'Chiudi' : 'Annulla'}
          </AlertDialogCancel>
          {!hasActiveIscrizioni && (
            <AlertDialogAction onClick={handleDelete} disabled={deleting}>
              {deleting ? 'Cancellando...' : 'Cancella'}
            </AlertDialogAction>
          )}
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
