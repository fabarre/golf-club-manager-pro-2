
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Database } from '@/integrations/supabase/types';

type StatoSocio = Database['public']['Enums']['stato_socio'];

interface SocioStatusBadgeProps {
  socio: any;
  onStatusChanged: () => void;
}

const stati: StatoSocio[] = ['Attivo', 'Inattivo', 'Sospeso'];

export const SocioStatusBadge = ({ socio, onStatusChanged }: SocioStatusBadgeProps) => {
  const [isChanging, setIsChanging] = useState(false);
  const { toast } = useToast();

  const handleStatusChange = async (newStatus: StatoSocio) => {
    setIsChanging(true);
    try {
      const { error } = await supabase
        .from('soci')
        .update({ stato: newStatus })
        .eq('id', socio.id);

      if (error) throw error;

      toast({ title: "Stato aggiornato con successo!" });
      onStatusChanged();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Errore",
        description: error.message,
      });
    } finally {
      setIsChanging(false);
    }
  };

  return (
    <Select
      value={socio.stato}
      onValueChange={handleStatusChange}
      disabled={isChanging}
    >
      <SelectTrigger className="w-auto border-none p-0 h-auto">
        <SelectValue asChild>
          <Badge 
            variant={socio.stato === 'Attivo' ? 'default' : 'secondary'}
            className="cursor-pointer hover:opacity-80"
          >
            {socio.stato}
          </Badge>
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        {stati.map((stato) => (
          <SelectItem key={stato} value={stato}>
            {stato}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};
