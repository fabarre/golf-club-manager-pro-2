
import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface Buca {
  numero: number;
  par: number;
  metri: number | null;
  handicap_index: number | null;
}

interface BucheFormProps {
  numeroBuche: number;
  onBucheChange: (buche: Buca[], parTotale: number) => void;
  initialBuche?: Buca[];
}

export const BucheForm = ({ numeroBuche, onBucheChange, initialBuche }: BucheFormProps) => {
  const [buche, setBuche] = useState<Buca[]>([]);

  // Inizializza le buche quando cambia il numero
  useEffect(() => {
    const newBuche: Buca[] = [];
    for (let i = 1; i <= numeroBuche; i++) {
      const existingBuca = initialBuche?.find(b => b.numero === i);
      newBuche.push(existingBuca || {
        numero: i,
        par: 4, // Default par 4
        metri: null,
        handicap_index: null,
      });
    }
    setBuche(newBuche);
  }, [numeroBuche, initialBuche]);

  // Calcola automaticamente i valori totali quando cambiano le buche
  useEffect(() => {
    const parTotale = buche.reduce((sum, buca) => sum + buca.par, 0);
    onBucheChange(buche, parTotale);
  }, [buche, onBucheChange]);

  const updateBuca = (numero: number, field: keyof Omit<Buca, 'numero'>, value: number | null) => {
    setBuche(prev => prev.map(buca => 
      buca.numero === numero 
        ? { ...buca, [field]: value }
        : buca
    ));
  };

  const handleParChange = (numero: number, value: string) => {
    const parValue = value ? parseInt(value) : 4;
    updateBuca(numero, 'par', Math.min(Math.max(parValue, 3), 6)); // Par tra 3 e 6
  };

  const handleMetriChange = (numero: number, value: string) => {
    const metri = value ? parseInt(value) : null;
    updateBuca(numero, 'metri', metri);
  };

  const handleHandicapChange = (numero: number, value: string) => {
    const handicap = value ? parseInt(value) : null;
    updateBuca(numero, 'handicap_index', handicap);
  };

  if (numeroBuche === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        Seleziona prima il numero di buche per configurare il percorso
      </div>
    );
  }

  const parTotale = buche.reduce((sum, buca) => sum + buca.par, 0);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Configurazione Buche</h3>
        <div className="text-sm font-medium">
          Par Totale: <span className="text-green-600 text-lg">{parTotale}</span>
        </div>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">Buca</TableHead>
              <TableHead className="w-20">Par</TableHead>
              <TableHead className="w-24">Metri</TableHead>
              <TableHead className="w-28">HCP Index</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {buche.map((buca) => (
              <TableRow key={buca.numero}>
                <TableCell className="font-medium">{buca.numero}</TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="3"
                    max="6"
                    value={buca.par}
                    onChange={(e) => handleParChange(buca.numero, e.target.value)}
                    className="w-16"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="50"
                    max="800"
                    value={buca.metri || ''}
                    onChange={(e) => handleMetriChange(buca.numero, e.target.value)}
                    placeholder="metri"
                    className="w-20"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="1"
                    max="18"
                    value={buca.handicap_index || ''}
                    onChange={(e) => handleHandicapChange(buca.numero, e.target.value)}
                    placeholder="1-18"
                    className="w-20"
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="text-xs text-gray-500">
        * Par: da 3 a 6 colpi per buca<br/>
        * HCP Index: difficoltà relativa della buca (1 = più difficile, 18 = più facile)
      </div>
    </div>
  );
};
