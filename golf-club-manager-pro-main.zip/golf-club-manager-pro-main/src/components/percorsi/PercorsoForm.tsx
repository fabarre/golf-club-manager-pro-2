
import { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { BucheForm } from './BucheForm';
import { useQuery } from '@tanstack/react-query';

const percorsoSchema = z.object({
  nome: z.string().min(1, 'Il nome è obbligatorio'),
  numero_buche: z.number().min(1, 'Il numero di buche deve essere almeno 1').max(36, 'Massimo 36 buche'),
  par: z.number().min(1, 'Il par deve essere almeno 1').optional(),
  course_rating: z.number().min(0, 'Il course rating deve essere positivo').optional(),
  slope_rating: z.number().min(55, 'Il slope rating minimo è 55').max(155, 'Il slope rating massimo è 155').optional(),
});

type PercorsoFormData = z.infer<typeof percorsoSchema>;

interface Buca {
  numero: number;
  par: number;
  metri: number | null;
  handicap_index: number | null;
}

interface PercorsoFormProps {
  percorso?: any;
  onSuccess: () => void;
  onCancel: () => void;
}

export const PercorsoForm = ({ percorso, onSuccess, onCancel }: PercorsoFormProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [buche, setBuche] = useState<Buca[]>([]);
  const [parTotale, setParTotale] = useState(0);
  const { toast } = useToast();

  // Carica le buche esistenti se stiamo modificando un percorso
  const { data: bucheEsistenti } = useQuery({
    queryKey: ['buche', percorso?.id],
    queryFn: async () => {
      if (!percorso?.id) return [];
      const { data, error } = await supabase
        .from('buche')
        .select('*')
        .eq('percorso_id', percorso.id)
        .order('numero');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!percorso?.id,
  });

  const form = useForm<PercorsoFormData>({
    resolver: zodResolver(percorsoSchema),
    defaultValues: {
      nome: percorso?.nome || '',
      numero_buche: percorso?.numero_buche || 18,
      par: percorso?.par || undefined,
      course_rating: percorso?.course_rating || undefined,
      slope_rating: percorso?.slope_rating || undefined,
    },
  });

  const numeroBuche = form.watch('numero_buche');

  const handleBucheChange = useCallback((newBuche: Buca[], newParTotale: number) => {
    setBuche(newBuche);
    setParTotale(newParTotale);
    
    // Aggiorna automaticamente il par totale nel form
    form.setValue('par', newParTotale);
  }, [form]);

  const onSubmit = async (data: PercorsoFormData) => {
    setIsSubmitting(true);
    try {
      const insertData = {
        nome: data.nome,
        numero_buche: data.numero_buche,
        par: parTotale || null, // Usa il par calcolato dalle buche
        course_rating: data.course_rating || null,
        slope_rating: data.slope_rating || null,
      };

      let percorsoId: string;

      if (percorso) {
        // Aggiorna percorso esistente
        const { error } = await supabase
          .from('percorsi')
          .update(insertData)
          .eq('id', percorso.id);
        
        if (error) throw error;
        percorsoId = percorso.id;

        // Elimina le buche esistenti
        await supabase
          .from('buche')
          .delete()
          .eq('percorso_id', percorsoId);
      } else {
        // Crea nuovo percorso
        const { data: newPercorso, error } = await supabase
          .from('percorsi')
          .insert(insertData)
          .select()
          .single();
        
        if (error) throw error;
        percorsoId = newPercorso.id;
      }

      // Inserisci le buche
      if (buche.length > 0) {
        const bucheData = buche.map(buca => ({
          percorso_id: percorsoId,
          numero: buca.numero,
          par: buca.par,
          metri: buca.metri,
          handicap_index: buca.handicap_index,
        }));

        const { error: bucheError } = await supabase
          .from('buche')
          .insert(bucheData);

        if (bucheError) throw bucheError;
      }

      toast({
        title: "Successo",
        description: `Percorso ${percorso ? 'aggiornato' : 'creato'} con successo`,
      });

      onSuccess();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Errore",
        description: error.message,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="nome"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome Percorso</FormLabel>
                <FormControl>
                  <Input placeholder="Es. Percorso Championship" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="numero_buche"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Numero Buche</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1" 
                    max="36"
                    {...field}
                    onChange={(e) => field.onChange(Number(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Il par totale viene calcolato automaticamente */}
          <FormField
            control={form.control}
            name="par"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Par Totale (calcolato automaticamente)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    {...field}
                    value={parTotale || ''}
                    readOnly
                    className="bg-gray-50"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="course_rating"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Course Rating</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.1"
                    min="0"
                    placeholder="Es. 71.5"
                    {...field}
                    value={field.value || ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="slope_rating"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Slope Rating</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="55"
                    max="155"
                    placeholder="Es. 113"
                    {...field}
                    value={field.value || ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annulla
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Salvataggio...' : percorso ? 'Aggiorna' : 'Salva'}
            </Button>
          </div>
        </form>
      </Form>

      {/* Form per le buche */}
      <BucheForm 
        numeroBuche={numeroBuche}
        onBucheChange={handleBucheChange}
        initialBuche={bucheEsistenti}
      />
    </div>
  );
};
