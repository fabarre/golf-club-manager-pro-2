
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';

interface PercorsoDeleteDialogProps {
  percorso: any;
  onSuccess: () => void;
  onCancel: () => void;
}

export const PercorsoDeleteDialog = ({ percorso, onSuccess, onCancel }: PercorsoDeleteDialogProps) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const { toast } = useToast();

  // Verifica se ci sono gare associate al percorso
  const { data: gareAssociate } = useQuery({
    queryKey: ['gare-percorso', percorso.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('gare')
        .select('id, nome, data')
        .eq('percorso_id', percorso.id);
      
      if (error) throw error;
      return data;
    },
    enabled: !!percorso,
  });

  // Verifica se ci sono tee times associati al percorso
  const { data: teeTimesAssociati } = useQuery({
    queryKey: ['tee-times-percorso', percorso.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tee_times')
        .select('id, data, ora')
        .eq('percorso_id', percorso.id);
      
      if (error) throw error;
      return data;
    },
    enabled: !!percorso,
  });

  const hasAssociations = (gareAssociate && gareAssociate.length > 0) || (teeTimesAssociati && teeTimesAssociati.length > 0);

  const handleDelete = async () => {
    if (hasAssociations) {
      toast({
        variant: "destructive",
        title: "Impossibile eliminare il percorso",
        description: "Il percorso è associato a gare o prenotazioni e non può essere eliminato.",
      });
      return;
    }

    setIsDeleting(true);
    try {
      const { error } = await supabase
        .from('percorsi')
        .delete()
        .eq('id', percorso.id);

      if (error) throw error;

      onSuccess();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Errore",
        description: error.message,
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <AlertDialog open={true} onOpenChange={onCancel}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>
            {hasAssociations ? 'Impossibile eliminare il percorso' : 'Conferma eliminazione'}
          </AlertDialogTitle>
          <AlertDialogDescription>
            {hasAssociations ? (
              <div className="space-y-3">
                <p>
                  Il percorso "<strong>{percorso.nome}</strong>" non può essere eliminato perché è associato a:
                </p>
                
                {gareAssociate && gareAssociate.length > 0 && (
                  <div>
                    <p className="font-medium">Gare associate:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      {gareAssociate.map((gara) => (
                        <li key={gara.id}>
                          {gara.nome} - {new Date(gara.data).toLocaleDateString('it-IT')}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {teeTimesAssociati && teeTimesAssociati.length > 0 && (
                  <div>
                    <p className="font-medium">Prenotazioni associate:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      {teeTimesAssociati.slice(0, 5).map((teeTime) => (
                        <li key={teeTime.id}>
                          {new Date(teeTime.data).toLocaleDateString('it-IT')} alle {teeTime.ora}
                        </li>
                      ))}
                      {teeTimesAssociati.length > 5 && (
                        <li>... e altre {teeTimesAssociati.length - 5} prenotazioni</li>
                      )}
                    </ul>
                  </div>
                )}
                
                <p>
                  Per eliminare questo percorso, rimuovi prima tutte le associazioni.
                </p>
              </div>
            ) : (
              `Sei sicuro di voler eliminare il percorso "${percorso.nome}"? Questa azione non può essere annullata.`
            )}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={onCancel}>
            {hasAssociations ? 'Chiudi' : 'Annulla'}
          </AlertDialogCancel>
          {!hasAssociations && (
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {isDeleting ? 'Eliminazione...' : 'Elimina'}
            </AlertDialogAction>
          )}
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
