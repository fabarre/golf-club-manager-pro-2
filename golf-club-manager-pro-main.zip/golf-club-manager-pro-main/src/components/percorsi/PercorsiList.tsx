
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { PercorsoForm } from './PercorsoForm';
import { PercorsoDeleteDialog } from './PercorsoDeleteDialog';
import { useToast } from '@/hooks/use-toast';
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';

export const PercorsiList = () => {
  const [showForm, setShowForm] = useState(false);
  const [editingPercorso, setEditingPercorso] = useState<any>(null);
  const [deletingPercorso, setDeletingPercorso] = useState<any>(null);
  const { toast } = useToast();

  const { data: percorsi, isLoading, refetch } = useQuery({
    queryKey: ['percorsi'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('percorsi')
        .select('*')
        .order('nome');
      
      if (error) throw error;
      return data;
    },
  });

  const handleEdit = (percorso: any) => {
    setEditingPercorso(percorso);
    setShowForm(true);
  };

  const handleDelete = (percorso: any) => {
    setDeletingPercorso(percorso);
  };

  const handleFormSuccess = () => {
    setShowForm(false);
    setEditingPercorso(null);
    refetch();
    toast({
      title: editingPercorso ? "Percorso aggiornato" : "Percorso aggiunto",
      description: "L'operazione è stata completata con successo.",
    });
  };

  const handleDeleteSuccess = () => {
    setDeletingPercorso(null);
    refetch();
    toast({
      title: "Percorso eliminato",
      description: "Il percorso è stato eliminato con successo.",
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Gestione Percorsi</h1>
        <Drawer open={showForm} onOpenChange={setShowForm}>
          <DrawerTrigger asChild>
            <Button onClick={() => setEditingPercorso(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Nuovo Percorso
            </Button>
          </DrawerTrigger>
          <DrawerContent className="h-[80vh]">
            <DrawerHeader>
              <DrawerTitle>
                {editingPercorso ? 'Modifica Percorso' : 'Nuovo Percorso'}
              </DrawerTitle>
              <DrawerDescription>
                {editingPercorso ? 'Modifica i dati del percorso' : 'Inserisci i dati del nuovo percorso'}
              </DrawerDescription>
            </DrawerHeader>
            <div className="px-4 pb-4 overflow-y-auto">
              <PercorsoForm
                percorso={editingPercorso}
                onSuccess={handleFormSuccess}
                onCancel={() => setShowForm(false)}
              />
            </div>
          </DrawerContent>
        </Drawer>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista Percorsi</CardTitle>
        </CardHeader>
        <CardContent>
          {percorsi?.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Nessun percorso trovato. Aggiungi il primo percorso.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Numero Buche</TableHead>
                  <TableHead>Par</TableHead>
                  <TableHead>Course Rating</TableHead>
                  <TableHead>Slope Rating</TableHead>
                  <TableHead className="text-right">Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {percorsi?.map((percorso) => (
                  <TableRow key={percorso.id}>
                    <TableCell className="font-medium">{percorso.nome}</TableCell>
                    <TableCell>{percorso.numero_buche || '-'}</TableCell>
                    <TableCell>{percorso.par || '-'}</TableCell>
                    <TableCell>{percorso.course_rating || '-'}</TableCell>
                    <TableCell>{percorso.slope_rating || '-'}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(percorso)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete(percorso)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {deletingPercorso && (
        <PercorsoDeleteDialog
          percorso={deletingPercorso}
          onSuccess={handleDeleteSuccess}
          onCancel={() => setDeletingPercorso(null)}
        />
      )}
    </div>
  );
};
