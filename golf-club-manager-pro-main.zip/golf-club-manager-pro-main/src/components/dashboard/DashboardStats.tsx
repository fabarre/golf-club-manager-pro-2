
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Users, Trophy, Calendar, CreditCard, UserCheck, TrendingUp, Target, Clock } from 'lucide-react';

export const DashboardStats = () => {
  const { data: stats } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: async () => {
      const [soci, gare, prenotazioni, incassi, iscrizioniGare, risultati, gareOggi, sociAttivi] = await Promise.all([
        supabase.from('soci').select('id', { count: 'exact' }),
        supabase.from('gare').select('id', { count: 'exact' }),
        supabase.from('tee_times').select('id', { count: 'exact' }),
        supabase.from('incassi').select('importo').gte('data', new Date().getFullYear() + '-01-01'),
        supabase.from('iscrizioni').select('id, pagato', { count: 'exact' }),
        supabase.from('risultati').select('id', { count: 'exact' }),
        supabase.from('gare').select('id', { count: 'exact' }).eq('data', new Date().toISOString().split('T')[0]),
        supabase.from('soci').select('id', { count: 'exact' }).eq('stato', 'Attivo'),
      ]);

      const totalIncassi = incassi.data?.reduce((sum, item) => sum + (item.importo || 0), 0) || 0;
      const iscrizioniPagate = iscrizioniGare.data?.filter(i => i.pagato)?.length || 0;
      const iscrizioniNonPagate = (iscrizioniGare.count || 0) - iscrizioniPagate;

      return {
        soci: soci.count || 0,
        sociAttivi: sociAttivi.count || 0,
        gare: gare.count || 0,
        gareOggi: gareOggi.count || 0,
        prenotazioni: prenotazioni.count || 0,
        incassi: totalIncassi,
        iscrizioniTotali: iscrizioniGare.count || 0,
        iscrizioniPagate,
        iscrizioniNonPagate,
        risultatiInseriti: risultati.count || 0,
      };
    },
  });

  const { data: prossimeGare } = useQuery({
    queryKey: ['prossime-gare'],
    queryFn: async () => {
      const { data } = await supabase
        .from('gare')
        .select('nome, data')
        .gte('data', new Date().toISOString().split('T')[0])
        .order('data', { ascending: true })
        .limit(3);
      return data || [];
    },
  });

  const { data: statisticheMensili } = useQuery({
    queryKey: ['statistiche-mensili'],
    queryFn: async () => {
      const currentMonth = new Date().getMonth() + 1;
      const currentYear = new Date().getFullYear();
      
      const [gareMese, incassiMese] = await Promise.all([
        supabase.from('gare').select('id', { count: 'exact' })
          .gte('data', `${currentYear}-${currentMonth.toString().padStart(2, '0')}-01`)
          .lt('data', `${currentYear}-${(currentMonth + 1).toString().padStart(2, '0')}-01`),
        supabase.from('incassi').select('importo')
          .gte('data', `${currentYear}-${currentMonth.toString().padStart(2, '0')}-01`)
          .lt('data', `${currentYear}-${(currentMonth + 1).toString().padStart(2, '0')}-01`),
      ]);

      const incassiMeseTotale = incassiMese.data?.reduce((sum, item) => sum + (item.importo || 0), 0) || 0;

      return {
        gareMese: gareMese.count || 0,
        incassiMese: incassiMeseTotale,
      };
    },
  });

  const mainStats = [
    {
      title: 'Soci Attivi',
      value: `${stats?.sociAttivi || 0}/${stats?.soci || 0}`,
      icon: Users,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Gare Totali',
      value: stats?.gare || 0,
      icon: Trophy,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      title: 'Prenotazioni',
      value: stats?.prenotazioni || 0,
      icon: Calendar,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
    },
    {
      title: 'Incassi Anno',
      value: `€${stats?.incassi?.toFixed(2) || '0.00'}`,
      icon: CreditCard,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
    },
  ];

  const additionalStats = [
    {
      title: 'Gare Oggi',
      value: stats?.gareOggi || 0,
      icon: Clock,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
    },
    {
      title: 'Iscrizioni Pagate',
      value: `${stats?.iscrizioniPagate || 0}/${stats?.iscrizioniTotali || 0}`,
      icon: UserCheck,
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
    },
    {
      title: 'Risultati Inseriti',
      value: stats?.risultatiInseriti || 0,
      icon: Target,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
    },
    {
      title: 'Gare Questo Mese',
      value: statisticheMensili?.gareMese || 0,
      icon: TrendingUp,
      color: 'text-teal-600',
      bgColor: 'bg-teal-50',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Statistiche Principali */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Panoramica Generale</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {mainStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                  <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                    <Icon className={`h-4 w-4 ${stat.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Statistiche Aggiuntive */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Dettagli Operativi</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {additionalStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                  <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                    <Icon className={`h-4 w-4 ${stat.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Informazioni Mensili e Prossime Gare */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Statistiche Mensili</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Gare programmate:</span>
              <span className="font-semibold">{statisticheMensili?.gareMese || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Incassi mese:</span>
              <span className="font-semibold">€{statisticheMensili?.incassiMese?.toFixed(2) || '0.00'}</span>
            </div>
            {stats?.iscrizioniNonPagate > 0 && (
              <div className="flex justify-between items-center p-2 bg-orange-50 rounded">
                <span className="text-sm text-orange-700">Pagamenti in sospeso:</span>
                <span className="font-semibold text-orange-700">{stats.iscrizioniNonPagate}</span>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Prossime Gare</CardTitle>
          </CardHeader>
          <CardContent>
            {prossimeGare && prossimeGare.length > 0 ? (
              <div className="space-y-3">
                {prossimeGare.map((gara, index) => (
                  <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <span className="text-sm font-medium">{gara.nome}</span>
                    <span className="text-sm text-gray-600">
                      {new Date(gara.data).toLocaleDateString('it-IT')}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500">Nessuna gara programmata</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
