
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Award, TrendingUp, Users, Target } from 'lucide-react';

interface StatisticheTablesProps {
  data: any;
}

export const StatisticheTables = ({ data }: StatisticheTablesProps) => {
  return (
    <div className="space-y-6">
      {/* Top Performers */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-yellow-600" />
            Top 10 Performers (Media Stableford)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {data?.topPerformers?.map((player: any, index: number) => (
              <div key={index} className="flex justify-between items-center p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                    index === 0 ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' :
                    index === 1 ? 'bg-gradient-to-r from-gray-300 to-gray-500' :
                    index === 2 ? 'bg-gradient-to-r from-amber-500 to-amber-700' : 'bg-gradient-to-r from-blue-400 to-blue-600'
                  }`}>
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{player.nome}</p>
                    <p className="text-sm text-gray-600 flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {player.numeroGare} gare giocate
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-blue-600">
                    {player.media.toFixed(1)}
                  </p>
                  <p className="text-sm text-gray-600">
                    {player.totalePunti} pt totali
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Dettaglio Distribuzione Handicap */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Dettaglio Distribuzione Handicap
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Range Handicap</TableHead>
                <TableHead className="text-center">Numero Soci</TableHead>
                <TableHead className="text-center">Percentuale</TableHead>
                <TableHead>Distribuzione</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data?.handicapRanges?.map((range: any, index: number) => {
                const total = data.handicapRanges.reduce((sum: number, r: any) => sum + r.count, 0);
                const percentage = total > 0 ? ((range.count / total) * 100).toFixed(1) : '0';
                
                return (
                  <TableRow key={index}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded"
                          style={{ backgroundColor: range.color }}
                        />
                        <span>Handicap {range.range}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center font-bold">
                      {range.count}
                    </TableCell>
                    <TableCell className="text-center">
                      {percentage}%
                    </TableCell>
                    <TableCell>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="h-2 rounded-full transition-all duration-300"
                          style={{ 
                            width: `${percentage}%`,
                            backgroundColor: range.color 
                          }}
                        />
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Statistiche Partecipazione */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Dettaglio Partecipazione alle Ultime Gare
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome Gara</TableHead>
                <TableHead>Data</TableHead>
                <TableHead className="text-center">Partecipanti</TableHead>
                <TableHead className="text-center">Trend</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data?.partecipazioneDati?.map((gara: any, index: number) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{gara.nome}</TableCell>
                  <TableCell>
                    {new Date(gara.data).toLocaleDateString('it-IT')}
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-sm font-medium">
                      {gara.partecipanti}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    {index > 0 && data.partecipazioneDati[index - 1] ? (
                      <span className={`text-sm ${
                        gara.partecipanti > data.partecipazioneDati[index - 1].partecipanti 
                          ? 'text-green-600' 
                          : gara.partecipanti < data.partecipazioneDati[index - 1].partecipanti
                          ? 'text-red-600'
                          : 'text-gray-600'
                      }`}>
                        {gara.partecipanti > data.partecipazioneDati[index - 1].partecipanti ? '↗️' : 
                         gara.partecipanti < data.partecipazioneDati[index - 1].partecipanti ? '↘️' : '➡️'}
                      </span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};
