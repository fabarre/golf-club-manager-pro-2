
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { StatisticheFilters, StatisticheFilters as FiltersType } from './StatisticheFilters';
import { StatisticheCharts } from './StatisticheCharts';
import { StatisticheTables } from './StatisticheTables';

interface MonthlyData {
  mese: string;
  gare?: number;
  iscrizioni?: number;
  incassi?: number;
}

interface PartecipazioneDati {
  nome: string;
  data: string;
  partecipanti: number;
}

interface HandicapRange {
  range: string;
  count: number;
  color: string;
}

interface TopPerformer {
  nome: string;
  totalePunti: number;
  numeroGare: number;
  media: number;
}

interface StatisticheData {
  gareByMonth: MonthlyData[];
  iscrizioniByMonth: MonthlyData[];
  incassiByMonth: MonthlyData[];
  partecipazioneDati: PartecipazioneDati[];
  handicapRanges: HandicapRange[];
  topPerformers: TopPerformer[];
}

export const StatisticheSection = () => {
  const [filters, setFilters] = useState<FiltersType>({
    anno: new Date().getFullYear(),
    soloIscritti: true
  });

  const { data: statisticheGenerali } = useQuery({
    queryKey: ['statistiche-generali', filters],
    queryFn: async (): Promise<StatisticheData> => {
      const currentYear = filters.anno;
      
      // Costruire filtri dinamici per le query
      let gareFilter = supabase
        .from('gare')
        .select('data, tipo')
        .gte('data', `${currentYear}-01-01`)
        .lte('data', `${currentYear}-12-31`)
        .order('data');

      if (filters.mese) {
        gareFilter = gareFilter
          .gte('data', `${currentYear}-${filters.mese.toString().padStart(2, '0')}-01`)
          .lt('data', `${currentYear}-${(filters.mese + 1).toString().padStart(2, '0')}-01`);
      }

      if (filters.tipoGara) {
        gareFilter = gareFilter.eq('tipo', filters.tipoGara);
      }

      let iscrizioniFilter = supabase
        .from('iscrizioni')
        .select(`
          data_iscrizione, 
          gara_id,
          gare!inner(data, tipo),
          soci!inner(sesso, handicap, iscritto_circolo)
        `)
        .gte('data_iscrizione', `${currentYear}-01-01`)
        .lte('data_iscrizione', `${currentYear}-12-31`);

      if (filters.mese) {
        iscrizioniFilter = iscrizioniFilter
          .gte('data_iscrizione', `${currentYear}-${filters.mese.toString().padStart(2, '0')}-01`)
          .lt('data_iscrizione', `${currentYear}-${(filters.mese + 1).toString().padStart(2, '0')}-01`);
      }

      // Fix: Only apply gender filter if it's a valid value ("M" or "F")
      if (filters.sesso && (filters.sesso === 'M' || filters.sesso === 'F')) {
        iscrizioniFilter = iscrizioniFilter.eq('soci.sesso', filters.sesso);
      }

      if (filters.soloIscritti) {
        iscrizioniFilter = iscrizioniFilter.eq('soci.iscritto_circolo', true);
      }

      const [
        garePerMese,
        iscrizioniPerMese,
        incassiPerMese,
        partecipazione,
        handicapDistribution,
        performanceTopPlayers
      ] = await Promise.all([
        gareFilter,
        iscrizioniFilter,
        
        // Incassi per mese con filtri
        supabase
          .from('incassi')
          .select('data, importo, tipo')
          .gte('data', `${currentYear}-01-01`)
          .lte('data', `${currentYear}-12-31`),
        
        // Partecipazione media con filtri
        supabase
          .from('iscrizioni')
          .select(`
            gara_id,
            gare!inner(nome, data, tipo),
            soci!inner(sesso, iscritto_circolo)
          `),
        
        // Distribuzione handicap con filtri
        supabase
          .from('soci')
          .select('handicap, sesso, iscritto_circolo')
          .eq('stato', 'Attivo')
          .not('handicap', 'is', null),
        
        // Performance top players con filtri
        supabase
          .from('risultati')
          .select(`
            punti_stableford,
            iscrizione_id,
            iscrizioni!inner(
              socio_id,
              gare!inner(data, tipo),
              soci!inner(nome, cognome, sesso, iscritto_circolo)
            )
          `)
          .order('punti_stableford', { ascending: false })
          .limit(100)
      ]);

      // Processa dati gare per mese
      const gareByMonth = Array.from({ length: 12 }, (_, i) => ({
        mese: new Date(0, i).toLocaleDateString('it-IT', { month: 'short' }),
        gare: 0
      }));

      garePerMese.data?.forEach(gara => {
        const month = new Date(gara.data).getMonth();
        gareByMonth[month].gare++;
      });

      // Processa dati iscrizioni per mese
      const iscrizioniByMonth = Array.from({ length: 12 }, (_, i) => ({
        mese: new Date(0, i).toLocaleDateString('it-IT', { month: 'short' }),
        iscrizioni: 0
      }));

      iscrizioniPerMese.data?.forEach(iscrizione => {
        const month = new Date(iscrizione.data_iscrizione).getMonth();
        iscrizioniByMonth[month].iscrizioni++;
      });

      // Processa dati incassi per mese
      const incassiByMonth = Array.from({ length: 12 }, (_, i) => ({
        mese: new Date(0, i).toLocaleDateString('it-IT', { month: 'short' }),
        incassi: 0
      }));

      incassiPerMese.data?.forEach(incasso => {
        const month = new Date(incasso.data).getMonth();
        incassiByMonth[month].incassi += incasso.importo || 0;
      });

      // Calcola partecipazione media con filtri applicati
      const gareConPartecipanti: Record<string, PartecipazioneDati> = {};
      partecipazione.data?.forEach(iscrizione => {
        // Applica filtri alla partecipazione - Fix gender filter check
        if (filters.sesso && filters.sesso !== 'tutti' && iscrizione.soci?.sesso !== filters.sesso) return;
        if (filters.soloIscritti && !iscrizione.soci?.iscritto_circolo) return;
        if (filters.tipoGara && iscrizione.gare?.tipo !== filters.tipoGara) return;
        
        const garaId = iscrizione.gara_id;
        if (!gareConPartecipanti[garaId]) {
          gareConPartecipanti[garaId] = {
            nome: iscrizione.gare?.nome || 'N/A',
            data: iscrizione.gare?.data || '',
            partecipanti: 0
          };
        }
        gareConPartecipanti[garaId].partecipanti++;
      });

      const partecipazioneDati = Object.values(gareConPartecipanti)
        .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())
        .slice(0, 10);

      // Distribuzione handicap con filtri
      const handicapRanges: HandicapRange[] = [
        { range: '0-10', count: 0, color: '#22c55e' },
        { range: '11-20', count: 0, color: '#3b82f6' },
        { range: '21-30', count: 0, color: '#f59e0b' },
        { range: '31-40', count: 0, color: '#ef4444' },
        { range: '41-54', count: 0, color: '#8b5cf6' }
      ];

      handicapDistribution.data?.forEach(socio => {
        // Applica filtri - Fix gender filter check
        if (filters.sesso && filters.sesso !== 'tutti' && socio.sesso !== filters.sesso) return;
        if (filters.soloIscritti && !socio.iscritto_circolo) return;
        
        const hcp = socio.handicap;
        if (filters.rangeHandicap) {
          const [min, max] = filters.rangeHandicap.split('-').map(Number);
          if (hcp < min || hcp > max) return;
        }
        
        if (hcp <= 10) handicapRanges[0].count++;
        else if (hcp <= 20) handicapRanges[1].count++;
        else if (hcp <= 30) handicapRanges[2].count++;
        else if (hcp <= 40) handicapRanges[3].count++;
        else handicapRanges[4].count++;
      });

      // Top performers con filtri
      const playerStats: Record<string, TopPerformer> = {};
      performanceTopPlayers.data?.forEach(risultato => {
        // Applica filtri - Fix gender filter check
        if (filters.sesso && filters.sesso !== 'tutti' && risultato.iscrizioni?.soci?.sesso !== filters.sesso) return;
        if (filters.soloIscritti && !risultato.iscrizioni?.soci?.iscritto_circolo) return;
        if (filters.tipoGara && risultato.iscrizioni?.gare?.tipo !== filters.tipoGara) return;
        
        const socioId = risultato.iscrizioni?.socio_id;
        const nome = `${risultato.iscrizioni?.soci?.nome || ''} ${risultato.iscrizioni?.soci?.cognome || ''}`;
        
        if (!playerStats[socioId]) {
          playerStats[socioId] = {
            nome,
            totalePunti: 0,
            numeroGare: 0,
            media: 0
          };
        }
        
        playerStats[socioId].totalePunti += risultato.punti_stableford || 0;
        playerStats[socioId].numeroGare++;
        playerStats[socioId].media = playerStats[socioId].totalePunti / playerStats[socioId].numeroGare;
      });

      const topPerformers = Object.values(playerStats)
        .filter(player => player.numeroGare >= 3)
        .sort((a, b) => b.media - a.media)
        .slice(0, 10);

      return {
        gareByMonth,
        iscrizioniByMonth,
        incassiByMonth,
        partecipazioneDati,
        handicapRanges,
        topPerformers
      };
    },
  });

  const chartConfig = {
    gare: { label: 'Gare', color: '#3b82f6' },
    iscrizioni: { label: 'Iscrizioni', color: '#22c55e' },
    incassi: { label: 'Incassi', color: '#f59e0b' },
    partecipanti: { label: 'Partecipanti', color: '#8b5cf6' }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Statistiche Complete e Personalizzate
        </h2>
      </div>

      {/* Filtri di Personalizzazione */}
      <StatisticheFilters onFiltersChange={setFilters} />

      <Tabs defaultValue="charts" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="charts">Grafici e Visualizzazioni</TabsTrigger>
          <TabsTrigger value="tables">Tabelle e Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="charts" className="space-y-6">
          <StatisticheCharts data={statisticheGenerali} chartConfig={chartConfig} />
        </TabsContent>

        <TabsContent value="tables" className="space-y-6">
          <StatisticheTables data={statisticheGenerali} />
        </TabsContent>
      </Tabs>
    </div>
  );
};
