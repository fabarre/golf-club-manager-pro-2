
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Calendar, Settings2, Filter } from 'lucide-react';

interface StatisticheFiltersProps {
  onFiltersChange: (filters: StatisticheFilters) => void;
}

export interface StatisticheFilters {
  anno: number;
  mese?: number;
  tipoGara?: string;
  rangeHandicap?: string;
  sesso?: string;
  soloIscritti?: boolean;
}

export const StatisticheFilters = ({ onFiltersChange }: StatisticheFiltersProps) => {
  const [filters, setFilters] = useState<StatisticheFilters>({
    anno: new Date().getFullYear(),
    soloIscritti: true
  });

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - i);
  const months = [
    { value: 1, label: 'Gennaio' },
    { value: 2, label: 'Febbraio' },
    { value: 3, label: 'Marzo' },
    { value: 4, label: 'Aprile' },
    { value: 5, label: 'Maggio' },
    { value: 6, label: 'Giugno' },
    { value: 7, label: 'Luglio' },
    { value: 8, label: 'Agosto' },
    { value: 9, label: 'Settembre' },
    { value: 10, label: 'Ottobre' },
    { value: 11, label: 'Novembre' },
    { value: 12, label: 'Dicembre' }
  ];

  const handleFilterChange = (key: keyof StatisticheFilters, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const resetFilters = () => {
    const defaultFilters: StatisticheFilters = {
      anno: currentYear,
      soloIscritti: true
    };
    setFilters(defaultFilters);
    onFiltersChange(defaultFilters);
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings2 className="h-5 w-5" />
          Filtri Personalizzazione
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Anno</label>
            <Select 
              value={filters.anno.toString()} 
              onValueChange={(value) => handleFilterChange('anno', parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Mese</label>
            <Select 
              value={filters.mese?.toString() || "tutti"} 
              onValueChange={(value) => handleFilterChange('mese', value === "tutti" ? undefined : parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tutti">Tutti i mesi</SelectItem>
                {months.map(month => (
                  <SelectItem key={month.value} value={month.value.toString()}>
                    {month.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Tipo Gara</label>
            <Select 
              value={filters.tipoGara || "tutte"} 
              onValueChange={(value) => handleFilterChange('tipoGara', value === "tutte" ? undefined : value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tutte">Tutte le gare</SelectItem>
                <SelectItem value="Gara Sociale">Gara Sociale</SelectItem>
                <SelectItem value="Torneo">Torneo</SelectItem>
                <SelectItem value="Campionato">Campionato</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Range Handicap</label>
            <Select 
              value={filters.rangeHandicap || "tutti"} 
              onValueChange={(value) => handleFilterChange('rangeHandicap', value === "tutti" ? undefined : value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tutti">Tutti i range</SelectItem>
                <SelectItem value="0-10">0-10</SelectItem>
                <SelectItem value="11-20">11-20</SelectItem>
                <SelectItem value="21-30">21-30</SelectItem>
                <SelectItem value="31-40">31-40</SelectItem>
                <SelectItem value="41-54">41-54</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Sesso</label>
            <Select 
              value={filters.sesso || "tutti"} 
              onValueChange={(value) => handleFilterChange('sesso', value === "tutti" ? undefined : value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tutti">Tutti</SelectItem>
                <SelectItem value="M">Maschile</SelectItem>
                <SelectItem value="F">Femminile</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Membri</label>
            <Select 
              value={filters.soloIscritti ? "iscritti" : "tutti"} 
              onValueChange={(value) => handleFilterChange('soloIscritti', value === "iscritti")}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tutti">Tutti i giocatori</SelectItem>
                <SelectItem value="iscritti">Solo iscritti</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={resetFilters}
            className="flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            Reset Filtri
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
