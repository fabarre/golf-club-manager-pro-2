
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { AlertTriangle, Users } from 'lucide-react';

interface CircoloDeleteDialogProps {
  circolo: any;
  onClose: () => void;
}

export const CircoloDeleteDialog = ({ circolo, onClose }: CircoloDeleteDialogProps) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Verifica se ci sono soci associati al circolo
  const { data: sociAssociati, isLoading: checkingAssociations } = useQuery({
    queryKey: ['soci-by-circolo', circolo?.nome],
    queryFn: async () => {
      if (!circolo) return [];
      
      const { data, error } = await supabase
        .from('soci')
        .select('nome, cognome, email')
        .eq('circolo_appartenenza', circolo.nome)
        .order('cognome', { ascending: true });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!circolo,
  });

  const handleDelete = async () => {
    if (!circolo) return;
    
    setLoading(true);
    try {
      const { error } = await supabase
        .from('circoli_italiani')
        .delete()
        .eq('id', circolo.id);
      
      if (error) throw error;
      
      toast({
        title: "Circolo eliminato",
        description: `Il circolo "${circolo.nome}" è stato eliminato con successo.`,
      });
      
      onClose();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Errore",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const canDelete = !sociAssociati || sociAssociati.length === 0;

  return (
    <Dialog open={!!circolo} onOpenChange={() => onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2 text-red-600" />
            Elimina Circolo
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p>Sei sicuro di voler eliminare il circolo:</p>
          <div className="bg-gray-50 p-3 rounded-md">
            <p className="font-semibold">{circolo?.nome}</p>
            {circolo?.citta && (
              <p className="text-sm text-gray-600">
                {circolo.citta}
                {circolo.provincia && ` (${circolo.provincia})`}
              </p>
            )}
          </div>

          {checkingAssociations ? (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-600 mx-auto"></div>
              <p className="mt-2 text-sm text-gray-600">Controllo soci associati...</p>
            </div>
          ) : !canDelete ? (
            <Alert className="border-red-200 bg-red-50">
              <Users className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <div className="space-y-2">
                  <p className="font-semibold">
                    Impossibile eliminare il circolo. Ci sono {sociAssociati?.length} soci associati:
                  </p>
                  <div className="max-h-32 overflow-y-auto">
                    {sociAssociati?.map((socio, index) => (
                      <div key={index} className="text-sm">
                        • {socio.cognome} {socio.nome}
                        {socio.email && ` (${socio.email})`}
                      </div>
                    ))}
                  </div>
                  <p className="text-sm mt-2">
                    Rimuovi prima l'associazione di questi soci al circolo per poterlo eliminare.
                  </p>
                </div>
              </AlertDescription>
            </Alert>
          ) : (
            <Alert className="border-green-200 bg-green-50">
              <AlertDescription className="text-green-800">
                Nessun socio associato a questo circolo. Puoi procedere con l'eliminazione.
              </AlertDescription>
            </Alert>
          )}

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose}>
              Annulla
            </Button>
            {canDelete && (
              <Button
                variant="destructive"
                onClick={handleDelete}
                disabled={loading || checkingAssociations}
              >
                {loading ? 'Eliminando...' : 'Elimina'}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
