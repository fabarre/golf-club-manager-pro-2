
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft } from 'lucide-react';

interface CircoloFormProps {
  circolo?: any;
  onClose: () => void;
}

export const CircoloForm = ({ circolo, onClose }: CircoloFormProps) => {
  const [formData, setFormData] = useState({
    nome: '',
    citta: '',
    provincia: '',
    regione: '',
  });
  
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (circolo) {
      setFormData({
        nome: circolo.nome || '',
        citta: circolo.citta || '',
        provincia: circolo.provincia || '',
        regione: circolo.regione || '',
      });
    }
  }, [circolo]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (circolo) {
        const { error } = await supabase
          .from('circoli_italiani')
          .update(formData)
          .eq('id', circolo.id);
        if (error) throw error;
        toast({ title: "Circolo aggiornato con successo!" });
      } else {
        const { error } = await supabase
          .from('circoli_italiani')
          .insert([formData]);
        if (error) throw error;
        toast({ title: "Circolo creato con successo!" });
      }
      onClose();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Errore",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" onClick={onClose}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Indietro
        </Button>
        <h2 className="text-2xl font-bold">
          {circolo ? 'Modifica Circolo' : 'Nuovo Circolo'}
        </h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Informazioni Circolo</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="nome">Nome Circolo *</Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                required
                placeholder="Es. Golf Club Milano"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="citta">Città</Label>
                <Input
                  id="citta"
                  value={formData.citta}
                  onChange={(e) => setFormData({ ...formData, citta: e.target.value })}
                  placeholder="Es. Milano"
                />
              </div>
              <div>
                <Label htmlFor="provincia">Provincia</Label>
                <Input
                  id="provincia"
                  value={formData.provincia}
                  onChange={(e) => setFormData({ ...formData, provincia: e.target.value })}
                  placeholder="Es. MI"
                  maxLength={2}
                />
              </div>
              <div>
                <Label htmlFor="regione">Regione</Label>
                <Input
                  id="regione"
                  value={formData.regione}
                  onChange={(e) => setFormData({ ...formData, regione: e.target.value })}
                  placeholder="Es. Lombardia"
                />
              </div>
            </div>

            <div className="flex space-x-4">
              <Button type="submit" disabled={loading}>
                {loading ? 'Salvando...' : 'Salva'}
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                Annulla
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
