
import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Building2, Plus, Edit, Trash2, Search } from 'lucide-react';
import { CircoloForm } from './CircoloForm';
import { CircoloDeleteDialog } from './CircoloDeleteDialog';

export const CircoliList = () => {
  const [showForm, setShowForm] = useState(false);
  const [editingCircolo, setEditingCircolo] = useState<any>(null);
  const [deletingCircolo, setDeletingCircolo] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: circoli, isLoading } = useQuery({
    queryKey: ['circoli-italiani'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('circoli_italiani')
        .select('*')
        .order('nome', { ascending: true });
      
      if (error) throw error;
      return data || [];
    },
  });

  const filteredCircoli = circoli?.filter(circolo =>
    circolo.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    circolo.citta?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    circolo.provincia?.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const handleEdit = (circolo: any) => {
    setEditingCircolo(circolo);
    setShowForm(true);
  };

  const handleDelete = (circolo: any) => {
    setDeletingCircolo(circolo);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingCircolo(null);
    queryClient.invalidateQueries({ queryKey: ['circoli-italiani'] });
  };

  const handleCloseDeleteDialog = () => {
    setDeletingCircolo(null);
    queryClient.invalidateQueries({ queryKey: ['circoli-italiani'] });
  };

  if (showForm) {
    return (
      <CircoloForm 
        circolo={editingCircolo} 
        onClose={handleCloseForm} 
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold flex items-center">
          <Building2 className="h-8 w-8 mr-3 text-green-600" />
          Gestione Circoli
        </h1>
        <Button onClick={() => setShowForm(true)} className="bg-green-600 hover:bg-green-700">
          <Plus className="h-4 w-4 mr-2" />
          Nuovo Circolo
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Ricerca Circoli</CardTitle>
          <div className="relative">
            <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
            <Input
              placeholder="Cerca per nome, città o provincia..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
              <p className="mt-2 text-gray-600">Caricamento circoli...</p>
            </div>
          ) : filteredCircoli.length === 0 ? (
            <div className="text-center py-8">
              <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">
                {searchTerm ? 'Nessun circolo trovato con i criteri di ricerca' : 'Nessun circolo presente'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCircoli.map((circolo) => (
                <Card key={circolo.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-lg">{circolo.nome}</h3>
                      <div className="flex space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(circolo)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(circolo)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    {circolo.citta && (
                      <p className="text-sm text-gray-600">
                        {circolo.citta}
                        {circolo.provincia && ` (${circolo.provincia})`}
                      </p>
                    )}
                    {circolo.regione && (
                      <p className="text-xs text-gray-500 mt-1">{circolo.regione}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {deletingCircolo && (
        <CircoloDeleteDialog
          circolo={deletingCircolo}
          onClose={handleCloseDeleteDialog}
        />
      )}
    </div>
  );
};
