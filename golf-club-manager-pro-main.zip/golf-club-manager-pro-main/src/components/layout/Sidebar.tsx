import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { 
  Users, 
  Trophy, 
  Building, 
  Route, 
  Calendar,
  Calculator,
  Target,
  Home,
  Menu,
  X,
  BarChart
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const Sidebar = ({ activeTab, onTabChange }: SidebarProps) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const menuItems = [
    { id: 'overview', label: 'Dashboard', icon: Home },
    { id: 'soci', label: 'Soci', icon: Users },
    { id: 'circoli', label: 'Circoli', icon: Building },
    { id: 'percorsi', label: 'Percorsi', icon: Route },
    { id: 'gare', label: 'Gare', icon: Trophy },
    { id: 'risultati', label: 'Risultati', icon: Calculator },
    { id: 'classifica-finale', label: 'Classifica Finale', icon: Target },
    { id: 'statistiche', label: 'Statistiche', icon: BarChart },
  ];

  return (
    <aside className={cn(
      "bg-white border-r border-gray-200 transition-all duration-300",
      isCollapsed ? "w-16" : "w-64"
    )}>
      <div className="p-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="w-full justify-center"
        >
          {isCollapsed ? <Menu className="h-4 w-4" /> : <X className="h-4 w-4" />}
        </Button>
      </div>
      
      <nav className="px-2 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Button
              key={item.id}
              variant={activeTab === item.id ? 'default' : 'ghost'}
              className={cn(
                "w-full justify-start",
                isCollapsed && "px-2"
              )}
              onClick={() => onTabChange(item.id)}
            >
              <Icon className="h-4 w-4" />
              {!isCollapsed && <span className="ml-2">{item.label}</span>}
            </Button>
          );
        })}
      </nav>
    </aside>
  );
};
