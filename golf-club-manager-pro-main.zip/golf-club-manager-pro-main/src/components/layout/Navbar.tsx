
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { User, Calendar, Users, Trophy, Settings, LogOut } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useEffect } from 'react';

export const Navbar = () => {
  const { toast } = useToast();

  const { data: profile } = useQuery({
    queryKey: ['profile'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
      
      return data;
    },
  });

  // Aggiorna automaticamente lo stato senior di tutti i soci al login
  useEffect(() => {
    const updateSeniorStatus = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          // Chiama la funzione per aggiornare lo stato senior
          const { error } = await supabase.rpc('update_senior_status');
          if (error) {
            console.error('Errore aggiornamento stato senior:', error);
          }
        }
      } catch (error) {
        console.error('Errore aggiornamento automatico senior:', error);
      }
    };

    if (profile) {
      updateSeniorStatus();
    }
  }, [profile]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Logout effettuato",
      description: "Arrivederci!",
    });
  };

  return (
    <nav className="bg-green-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Trophy className="h-8 w-8" />
          <h1 className="text-xl font-bold">Golf Club Manager</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          {profile && (
            <>
              <span className="text-sm">
                {profile.nome} {profile.cognome} ({profile.role})
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-white hover:bg-green-700"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};
